/* game.js + assets.js 런타임 스모크 테스트 (Node, DOM 스텁) */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

/* ---- 캔버스 2D 스텁 ---- */
function makeCtx() {
  const grad = { addColorStop() {} };
  return new Proxy({}, {
    get(t, k) {
      if (k === "measureText") return (s) => ({ width: String(s).length * 7 });
      if (k === "createLinearGradient" || k === "createRadialGradient" || k === "createPattern") return () => grad;
      if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4).fill(255), width: w, height: h });
      if (k === "putImageData") return () => {};
      if (typeof k === "string" && !(k in t)) {
        t[k] = (...a) => undefined;
      }
      return t[k];
    },
    set(t, k, v) { t[k] = v; return true; },
  });
}
function makeCanvas(id) {
  const el = makeEl(id);
  el.width = 1280; el.height = 720;
  el.getContext = () => makeCtx();
  el.getBoundingClientRect = () => ({ left: 0, top: 0, width: 1280, height: 720 });
  return el;
}
function makeEl(id) {
  const store = {};
  return {
    id, style: store, dataset: {},
    classList: { add() {}, remove() {}, contains: () => false, toggle() {} },
    innerHTML: "", textContent: "",
    addEventListener() {}, removeEventListener() {},
    querySelectorAll: () => [],
    setAttribute() {},
  };
}

const elements = {};
const ids = ["hud","hud-name","hud-lv","hp-fill","hp-text","mp-fill","mp-text","hud-gold",
  "hud-floor","hud-quest","hotbar","minimap","win-body","win-modal","win-title","win-close"];
ids.forEach(i => elements[i] = makeEl(i));
elements.minimap = makeCanvas("minimap");
elements.game = makeCanvas("game");

const winListeners = {};
const rafQueue = [];
let imgSeq = 0;

const sandbox = {
  console,
  Math, Date, Uint8ClampedArray, Promise, Object, Array, JSON, Set, Map, parseInt, parseFloat, String, Number, Boolean, Error,
  performance: { now: () => Date.now() },
  requestAnimationFrame: (cb) => { rafQueue.push(cb); },
  setTimeout: (cb) => cb(),
  document: {
    getElementById: (id) => elements[id] || null,
    createElement: (tag) => makeCanvas(tag),
    querySelectorAll: () => [],
  },
  window: {},
  Image: class {
    constructor() { this._src = ""; }
    set src(v) {
      this._src = v; imgSeq++;
      // 비동기 로드 성공 시뮬레이션
      Promise.resolve().then(() => this.onload && this.onload());
    }
    get src() { return this._src; }
  },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
sandbox.window.addEventListener = (ev, cb) => { (winListeners[ev] = winListeners[ev] || []).push(cb); };

vm.createContext(sandbox);

function load(file) {
  const code = fs.readFileSync(path.join(__dirname, "..", "js", file), "utf8");
  vm.runInContext(code, sandbox, { filename: file });
}

process.on("unhandledRejection", (e) => { console.error("UNHANDLED", e); process.exit(1); });

let t = 0;
function frames(n) {
  for (let i = 0; i < n; i++) {
    t += 16.7;
    const q = rafQueue.splice(0);
    if (!q.length) break;
    q.forEach(cb => cb(t));
  }
}
function key(k, down = true) {
  (winListeners[down ? "keydown" : "keyup"] || []).forEach(cb => cb({ key: k, preventDefault() {} }));
}
function click() {
  // canvas listeners는 스텁이라 직접 호출 불가 — __DBG로 우회
}

const failures = [];
function step(name, fn) {
  try { fn(); console.log("✔", name); }
  catch (e) { failures.push(name); console.error("✘", name, "\n   ", e.stack.split("\n").slice(0, 4).join("\n    ")); }
}

(async () => {
  load("monsters.js");
  load("assets.js");
  load("game.js");
  const D = sandbox.window.__DBG;
  const S = D.state;

  step("타이틀 렌더 60프레임", () => frames(60));
  step("에셋 로드 대기", async () => { for (let i = 0; i < 50 && !D.GFX.on; i++) await Promise.resolve(), frames(2); if (!D.GFX.on) throw new Error("GFX 미활성"); });
  step("스토리 시작", () => D.pickStory(0));
  step("마을 렌더 + 이동(WASD)", () => { key("d"); frames(90); key("d", false); key("w"); frames(40); key("w", false); });
  step("NPC 대화(촌장)", () => { S.player.x = 5; S.player.y = 6; D.tryInteract(); frames(10); key(" "); frames(5); key(" "); frames(5); key(" "); frames(5); });
  step("우물 재앙 대화", () => { const w = S.npcs.find(n => n.name === "갈래 우물"); S.player.x = w.x; S.player.y = w.y + 1; D.tryInteract(); frames(5); key(" "); frames(30); });
  step("E 힌트/파티클/토스트 렌더", () => frames(90));
  step("불탄 마을", () => { S.player.burned = true; D.spawnFloor(); frames(60); });
  step("던전 진입", () => { S.floor = 1; S.player.dungeon = "ember"; D.spawnFloor(); frames(60); key("a"); frames(50); key("a", false); });
  step("전투 시작", () => { const en = S.enemies.find(e => e.alive) || S.enemies[0]; D.startBattle(en); frames(30); });
  step("전투: 공격", () => { D.battleAct("atk"); frames(40); });
  step("전투: 스킬", () => { D.battleAct("skill"); frames(40); });
  step("전투: 적 턴 진행", () => { frames(80); });
  step("전투: 아이템/도망 시도", () => { D.battleAct("item"); frames(10); D.battleAct("run"); frames(80); });
  step("전투 종료까지", () => {
    let guard = 0;
    while (S.screen === "battle" && guard++ < 200) {
      if (S.battle.turn === "player") { S.player.mp = 99; D.battleAct("skill"); }
      frames(90);
    }
    if (guard >= 200) throw new Error("전투 무한루프");
    frames(30);
  });
  step("3층 지워진 해의 자리", () => { S.floor = 3; S.player.dungeon = "haesung"; D.spawnFloor(); const n = S.npcs.find(x => x.name === "지워진 해의 자리"); if (n) { S.player.x = n.x; S.player.y = n.y + 1; D.tryInteract(); frames(10); key(" "); frames(5); key(" "); frames(5); } frames(40); });
  step("개연의 제단(tide 2층)", () => { S.floor = 2; S.player.dungeon = "tide"; D.spawnFloor(); const n = S.npcs.find(x => x.name === "개연의 제단"); if (n) { S.player.x = n.x; S.player.y = n.y + 1; D.tryInteract(); frames(10); key(" "); frames(5); } frames(30); });
  step("승리 화면", () => { S.player.codex.add("fold_dust"); S.player.relic = "relic_dream"; S.screen = "win"; frames(40); key("Enter"); frames(10); });
  step("재시작 + 긴 이동", () => { D.pickStory(0); key("d"); frames(120); key("d", false); key("s"); frames(80); key("s", false); frames(40); });

  console.log(failures.length ? `\n실패 ${failures.length}건: ${failures.join(", ")}` : "\n전체 통과");
  process.exit(failures.length ? 1 : 0);
})();
