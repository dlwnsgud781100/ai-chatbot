/* ============================================================
 * assets.js — Mystic Woods 에셋 파이프라인 (극 · 에코 오브 아스안)
 * 에셋: Game Endeavor, Mystic Woods 16x16 (free 2.1, 비영리)
 *  - 로딩 실패 시에도 게임은 폴백(도형 렌더링)으로 동작한다.
 * ============================================================ */
window.Assets = (() => {
  const IMG = {};
  const ready = { ok: false };
  const listeners = [];
  const F = {}; // 프레임 캐시

  const FILES = {
    player:  "assets/img/player.png",
    slime:   "assets/img/slime.png",
    grass:   "assets/img/grass.png",
    plains:  "assets/img/plains.png",
    water1:  "assets/img/water1.png",
    water2:  "assets/img/water2.png",
    water3:  "assets/img/water3.png",
    water4:  "assets/img/water4.png",
    water5:  "assets/img/water5.png",
    water6:  "assets/img/water6.png",
    walls:   "assets/img/walls.png",
    door:    "assets/img/wooden_door.png",
    wooden:  "assets/img/wooden.png",
    carpet:  "assets/img/carpet.png",
    decor16: "assets/img/decor16.png",
    fences:  "assets/img/fences.png",
    objects: "assets/img/objects.png",
    chest:   "assets/img/chest_01.png",
    chest2:  "assets/img/chest_02.png",
    dust:    "assets/img/dust.png",
  };

  function loadOne(key, src) {
    return new Promise(res => {
      const im = new Image();
      im.onload = () => { IMG[key] = im; res(true); };
      im.onerror = () => { console.warn("[assets] load fail:", src); res(false); };
      im.src = src;
    });
  }

  /* --- 캔버스 유틸 --- */
  function cv(w, h) {
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const x = c.getContext("2d");
    x.imageSmoothingEnabled = false;
    return [c, x];
  }
  function crop(src, sx, sy, sw, sh) {
    const [c, x] = cv(sw, sh);
    x.drawImage(IMG[src], sx, sy, sw, sh, 0, 0, sw, sh);
    return c;
  }
  function mirror(srcCanvas) {
    const [c, x] = cv(srcCanvas.width, srcCanvas.height);
    x.translate(srcCanvas.width, 0);
    x.scale(-1, 1);
    x.drawImage(srcCanvas, 0, 0);
    return c;
  }
  function hexRGB(hex) {
    const h = hex.replace("#", "");
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  /* 명도 기반 단색 틴트: 밝은 픽셀 = 색, 어두운 픽셀 = 어두운 색 */
  function tint(srcCanvas, color, keepDark) {
    const [r, g, b] = hexRGB(color);
    const [c, x] = cv(srcCanvas.width, srcCanvas.height);
    x.drawImage(srcCanvas, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height);
    const p = d.data;
    for (let i = 0; i < p.length; i += 4) {
      if (p[i + 3] < 12) continue;
      const L = (0.30 * p[i] + 0.59 * p[i + 1] + 0.11 * p[i + 2]) / 255;
      const t = Math.max(0, Math.min(1, L * 1.25));
      const k = keepDark ? 0.45 : 0.25; // 그림자 최소 밝기 비율
      p[i]     = Math.round(r * (k + (1 - k) * t));
      p[i + 1] = Math.round(g * (k + (1 - k) * t));
      p[i + 2] = Math.round(b * (k + (1 - k) * t));
    }
    x.putImageData(d, 0, 0);
    return c;
  }

  /* ---------------- 프레임 추출 ---------------- */
  function build() {
    const bad = [];
    const need = (...keys) => keys.forEach(k => { if (!IMG[k]) bad.push(k); });
    need("player", "slime", "grass", "plains", "walls", "wooden", "objects", "chest", "dust");
    if (bad.length) { console.warn("[assets] 누락:", bad); return false; }

    /* 플레이어: 48px 셀. 밴드 0~2 대기(하/좌/상), 3~5 걷기, 6~9 공격 */
    const PW = 40, PH = 34, PX = 4, PY = 14;
    const pBand = (band, cols, wide) => {
      const arr = [];
      for (let c = 0; c < cols; c++) {
        const w = wide ? PW : 30;
        const [cc, xx] = cv(w, PH);
        const sx = band < 6
          ? c * 48 + (48 - w) / 2
          : c * 48 + (48 - w) / 2;
        xx.drawImage(IMG.player, Math.round(sx), band * 48 + PY, w, PH, 0, 0, w, PH);
        // 빈 프레임 검증
        const d = xx.getImageData(0, 0, w, PH).data;
        let n = 0;
        for (let i = 3; i < d.length; i += 4) if (d[i] > 12) n++;
        if (n > 40) arr.push(cc);
      }
      return arr;
    };
    F.player = {
      idle:  { down: pBand(0, 6), left: pBand(1, 6), up: pBand(2, 6) },
      walk:  { down: pBand(3, 6), left: pBand(4, 6), up: pBand(5, 6) },
      atk:   { down: pBand(6, 4, true), left: pBand(7, 4, true), up: pBand(8, 4, true), right: pBand(9, 4, true) },
    };
    F.player.idle.right = F.player.idle.left.map(mirror);
    F.player.walk.right = F.player.walk.left.map(mirror);
    F.player.atk.rightAlt = F.player.atk.left.map(mirror);
    F.playerAnchor = { x: 20, y: 32 }; // 발 기준 앵커(프레임 내 좌표)

    /* 슬라임: 32px 셀, 밴드별 프레임 수 [4,6,7,3,5] — bbox 정규화(하단 중앙 앵커) */
    const sBand = (row, cols) => {
      const raw = [];
      for (let c = 0; c < cols; c++) {
        const [cc, xx] = cv(32, 32);
        xx.drawImage(IMG.slime, c * 32, row * 32, 32, 32, 0, 0, 32, 32);
        const d = xx.getImageData(0, 0, 32, 32).data;
        let n = 0;
        for (let i = 3; i < d.length; i += 4) if (d[i] > 12) n++;
        if (n > 30) raw.push(cc);
      }
      // 프레임별 bbox로 잘라 바닥 정렬
      return raw.map(src => {
        const sx = src.getContext("2d");
        const d = sx.getImageData(0, 0, 32, 32).data;
        let x0 = 32, y0 = 32, x1 = -1, y1 = -1;
        for (let y = 0; y < 32; y++) for (let x = 0; x < 32; x++) {
          if (d[(y * 32 + x) * 4 + 3] > 12) {
            if (x < x0) x0 = x; if (x > x1) x1 = x;
            if (y < y0) y0 = y; if (y > y1) y1 = y;
          }
        }
        if (x1 < 0) return src;
        const w = x1 - x0 + 1, h = y1 - y0 + 1;
        const [cc, xx] = cv(34, 34); // 여유 포함
        xx.drawImage(src, x0, y0, w, h, 17 - (w >> 1), 34 - h, w, h);
        return cc;
      });
    };
    F.slime = {
      idle:  sBand(0, 4),
      move:  sBand(1, 6),
      atk:   sBand(2, 7),
      hit:   sBand(3, 3),
      extra: sBand(4, 5),
    };
    F.slimeFramesOk = F.slime.move.length >= 4;
    F._slimeCache = new Map();
    F.slimeTint = color => {
      if (F._slimeCache.has(color)) return F._slimeCache.get(color);
      const set = {
        idle:  F.slime.idle.map(c => tint(c, color)),
        move:  F.slime.move.map(c => tint(c, color)),
        atk:   F.slime.atk.map(c => tint(c, color)),
        hit:   F.slime.hit.map(c => tint(c, color)),
      };
      F._slimeCache.set(color, set);
      return set;
    };
    F._peopleCache = new Map();
    F.personTint = color => {
      if (F._peopleCache.has(color)) return F._peopleCache.get(color);
      const set = { idle: F.player.idle.down.map(c => tint(c, color, true)) };
      F._peopleCache.set(color, set);
      return set;
    };

    /* 타일 */
    F.tiles = {};
    F.tiles.grass = [crop("grass", 0, 0, 16, 16)];
    if (IMG.decor16) {
      F.tiles.grass.push(crop("decor16", 16, 0, 16, 16));
      F.tiles.grass.push(crop("decor16", 32, 0, 16, 16));
      F.tiles.grass.push(crop("decor16", 48, 0, 16, 16));
    } else F.tiles.grass.push(F.tiles.grass[0], F.tiles.grass[0], F.tiles.grass[0]);
    F.tiles.dirt = IMG.plains ? [
      crop("plains", 64, 0, 16, 16), crop("plains", 80, 0, 16, 16),
      crop("plains", 64, 16, 16, 16), crop("plains", 80, 16, 16, 16),
      crop("plains", 64, 32, 16, 16), crop("plains", 80, 32, 16, 16),
    ] : F.tiles.grass;
    F.tiles.wood = [crop("wooden", 0, 0, 16, 16)];
    F.tiles.carpet = IMG.carpet ? [crop("carpet", 64, 0, 16, 16), crop("carpet", 80, 0, 16, 16)] : F.tiles.wood;
    F.tiles.wallTop = crop("walls", 0, 16, 16, 32);
    F.tiles.wallFace = crop("walls", 0, 64, 16, 80);
    F.tiles.wallTop2 = crop("walls", 32, 16, 16, 32);
    F.tiles.wallFace2 = crop("walls", 32, 64, 16, 80);
    F.tiles.door = IMG.door ? crop("door", 0, 0, 16, 16) : F.tiles.wallFace;
    F.tiles.doorB = IMG.door ? crop("door", 16, 0, 16, 16) : F.tiles.wallFace;
    F.tiles.fence = IMG.fences ? crop("fences", 0, 0, 16, 16) : null;
    F.tiles.fenceH = IMG.fences ? crop("fences", 16, 0, 16, 16) : null;

    /* 물 애니메이션: 각 waterN의 (2,0) 셀 */
    F.water = [];
    for (let i = 1; i <= 6; i++) {
      if (IMG["water" + i]) F.water.push(crop("water" + i, 32, 0, 16, 16));
    }
    F.waterOk = F.water.length === 6;
    F.waterAlt = [];
    for (let i = 1; i <= 6; i++) {
      if (IMG["water" + i]) F.waterAlt.push(crop("water" + i, 16, 0, 16, 16));
    }

    /* 프롭 */
    F.props = {};
    F.props.treeClump = IMG.plains ? crop("plains", 0, 0, 64, 48) : null;   // 마른 풀 위 나무 군락
    F.props.bush = IMG.objects ? crop("objects", 104, 98, 28, 20) : null;
    F.props.rock = IMG.objects ? crop("objects", 52, 96, 40, 30) : null;
    F.props.crystal = IMG.objects ? crop("objects", 198, 26, 38, 40) : null;

    /* 상자: 닫힘 → 열림 4프레임 */
    F.chest = [0, 1, 2, 3].map(i => crop("chest", i * 16, 0, 16, 16));
    F.chest2 = IMG.chest2 ? [0, 1, 2, 3].map(i => crop("chest2", i * 16, 0, 16, 16)) : F.chest;

    /* 먼지 파티클 4프레임 */
    F.dust = [0, 1, 2, 3].map(i => crop("dust", i * 12, 0, 12, 12));

    F.well = makeWell();
    F.stele = makeStele();

    ready.ok = true;
    return true;
  }

  /* ---------- 절차적 소품 ---------- */
  function makeWell() {
    const [c, x] = cv(36, 34);
    // 돌 테두리(위에서 본 우물)
    x.drawImage(F.tiles.wallTop, 0, 0, 16, 16, 4, 12, 12, 12);
    x.drawImage(F.tiles.wallTop, 0, 0, 16, 16, 16, 12, 12, 12);
    x.drawImage(F.tiles.wallTop, 0, 0, 16, 16, 4, 22, 12, 12);
    x.drawImage(F.tiles.wallTop, 0, 0, 16, 16, 16, 22, 12, 12);
    // 내부 어두운 물
    const [wc, wx] = cv(16, 16);
    const wg = wx.createLinearGradient(0, 0, 0, 16);
    wg.addColorStop(0, "#1d3a55"); wg.addColorStop(1, "#0d1f33");
    wx.fillStyle = wg; wx.fillRect(0, 0, 16, 16);
    wx.fillStyle = "#4f89b8"; wx.fillRect(3, 4, 6, 1); wx.fillRect(9, 10, 4, 1);
    x.drawImage(wc, 8, 16, 16, 14);
    // 두 지주 + 지붕
    x.fillStyle = "#6b4a2b"; x.fillRect(2, 2, 3, 22); x.fillRect(31, 2, 3, 22);
    x.fillStyle = "#8a6136"; x.fillRect(2, 2, 3, 2); x.fillRect(31, 2, 3, 2);
    x.fillStyle = "#4a331e";
    x.fillRect(0, 0, 36, 3); x.fillRect(2, 3, 32, 2);
    x.fillStyle = "#2e1f12"; x.fillRect(0, 4, 36, 1);
    return c;
  }
  function makeStele() {
    const [c, x] = cv(20, 30);
    x.drawImage(F.tiles.wallFace, 0, 0, 16, 16, 2, 4, 16, 20);
    x.drawImage(F.tiles.wallFace, 0, 0, 16, 16, 2, 8, 16, 20);
    x.fillStyle = "rgba(14,18,26,.55)"; x.fillRect(2, 4, 16, 22);
    x.fillStyle = "#9fb6c8";
    x.fillRect(6, 8, 8, 1); x.fillRect(8, 10, 4, 1);
    x.fillRect(6, 13, 8, 1); x.fillRect(8, 15, 4, 1);
    x.fillStyle = "#5c7186"; x.fillRect(4, 26, 12, 2);
    x.fillStyle = "rgba(159,182,200,.25)"; x.fillRect(5, 7, 10, 10);
    return c;
  }

  /* ---------- API ---------- */
  function onReady(cb) {
    if (ready.ok) { cb(true); return; }
    listeners.push(cb);
  }
  function boot() {
    const entries = Object.entries(FILES);
    return Promise.all(entries.map(([k, v]) => loadOne(k, v))).then(() => {
      const ok = build();
      listeners.forEach(cb => cb(ok));
      return ok;
    }).catch(() => { listeners.forEach(cb => cb(false)); return false; });
  }

  return {
    F, ready, boot, onReady,
    drawDust(x, px, py, t, scale) {
      if (!ready.ok) return;
      const i = Math.min(3, Math.floor(t));
      x.drawImage(F.dust[i], px, py, 12 * scale, 12 * scale);
    },
  };
})();
