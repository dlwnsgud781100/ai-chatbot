(() => {
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  const TILE = 32;
  const keys = Object.create(null);

  const STORIES = [
    {
      id: "haesung",
      title: "길려진 해의 기성",
      blurb: "아스안 북동쪽 숲의 버려진 던전. 해가 길려 나간 성.",
      color: "#6a7a88",
    },
  ];

  const ITEMS = {
    herb: { name: "제단 약초", type: "heal", val: 12 },
    ether: { name: "신유(神油)", type: "mana", val: 8 },
    ember_shard: { name: "식지 않는 재", type: "key" },
    tide_pearl: { name: "거울 파편", type: "key" },
    root_seed: { name: "금이 간 잔", type: "key" },
    wrath_blade: { name: "금 간 칼날", type: "key" },
    envy_eye: { name: "거꾸로 눈", type: "key" },
    glutton_seed: { name: "끝없는 씨", type: "key" },
    sloth_sand: { name: "멈춘 모래", type: "key" },
    rusty_sword: { name: "잔신의 녹슨 검", type: "atk", val: 2 },
    relic_crown: { name: "색욕·분노의 봉인", type: "relic" },
    relic_name: { name: "교만·질투의 봉인", type: "relic" },
    relic_dream: { name: "탐·포·면의 봉인", type: "relic" },
    god_thread: { name: "신의 개연 파편", type: "key" },
  };

  const HOOKS = {
    H01: { title: "국교가 된 악성", line: "왕도가 악성을 법으로 섬긴다. 나라 이름은 아직 없다." },
    H02: { title: "미개봉 봉랍", line: "전령의 편지: 「법령이 사람을 먹는다」. 봉인을 열 손이 없다." },
    H03: { title: "건너뛴 계절", line: "달력 돌의 숫자가 하루를 삼켰다. 세계가 달력을 씹는 중." },
    H04: { title: "하늘의 구멍", line: "광인이 궤도 제단을 말한다. 마을은 헛소리로 듣는다." },
    H05: { title: "지도에 없는 먼지", line: "다른 땅에서 온 먼지. 항로라는 낱말만 남았다." },
    H06: { title: "나선 스케치", line: "등대지기 유품. 바닷가로 오해되는 그림. 팔이 너무 많다." },
    H07: { title: "은하를 잇는 실", line: "아이가 쥔 실. 끊기면 떨어진다고만 했다." },
    H08: { title: "1이 1이 아닌 밤", line: "우물가 낙서. 상수 신전의 예고로 읽히지 않는다." },
    H09: { title: "같은 얼굴의 메아리", line: "갈래 우물에 자신과 다른 자신이 있다." },
    H10: { title: "글이 도는 비석", line: "축이 빈 비석. 의미가 붙었다가 빠진다." },
    H11: { title: "문 없는 문짝", line: "닫혀 있으나 문이 없다. 극의 이름은 적혀 있지 않다." },
    H12: { title: "접힌 자국", line: "여행자의 상처는 칼이 아니다. 세계가 접힌 자리." },
    H13: { title: "다시 피는 종양", line: "악성은 죽어도 국경 너머에서 다시 핀다." },
    H14: { title: "일곱이면 극?", line: "수집가는 파편 일곱이 극의 문을 연다고 한다. 너무 쉽다." },
    H15: { title: "비는 문장", line: "어떤 말은 끝나기 전에 사라진다. …" },
    H16: { title: "길려진 해", line: "기성 3층. 해가 길려 나가고 성만 남았다. 형상은 없었다." },
  };

  const MONSTERS = window.VILLAGE_MONSTERS;

  const state = {
    screen: "title", // title | play | battle | dialog | win
    story: null,
    hover: -1,
    player: null,
    map: null,
    floor: 0,
    npcs: [],
    enemies: [],
    chests: [],
    stairs: null,
    log: [],
    dialog: null,
    battle: null,
    time: 0,
    camera: { x: 0, y: 0 },
  };

  function log(msg, imp) {
    state.log.unshift({ msg, imp: !!imp, t: Date.now() });
    if (state.log.length > 40) state.log.pop();
    renderPanel();
  }

  const panels = { log: "", quest: "", inv: "", codex: "", hook: "" };

  function hud() {
    const p = state.player;
    const hudEl = document.getElementById("hud");
    if (!p) { hudEl.classList.add("hidden"); return; }
    hudEl.classList.remove("hidden");
    document.getElementById("hud-name").textContent = p.name;
    document.getElementById("hud-lv").textContent = p.lv;
    document.getElementById("hp-fill").style.width = (100 * p.hp / p.maxHp) + "%";
    document.getElementById("hp-text").textContent = p.hp + "/" + p.maxHp;
    document.getElementById("mp-fill").style.width = (100 * p.mp / p.maxMp) + "%";
    document.getElementById("mp-text").textContent = p.mp + "/" + p.maxMp;
    document.getElementById("hud-gold").textContent = p.gold;
    document.getElementById("hud-floor").textContent = state.floor === 0 ? "아스안 마을" : "길려진 해의 기성 " + state.floor + "층";
    const main = p.quests.find(q => q.kind === "main");
    const spec = p.quests.find(q => q.kind === "special" && !q.done);
    document.getElementById("hud-quest").innerHTML = main
      ? `<b>${main.title}</b> ${main.cur}/${main.need}` + (spec ? `<br>⚠ ${spec.title}` : "")
      : "";
    const hb = document.getElementById("hotbar");
    if (hb) {
      const keys = Object.entries(p.inv).filter(([, n]) => n > 0).slice(0, 8);
      while (keys.length < 8) keys.push(["", 0]);
      hb.innerHTML = keys.map(([k, n], i) =>
        `<div class="slot">${k ? ITEMS[k].name + "<br>×" + n : (i + 1)}</div>`
      ).join("");
    }
  }

  function renderPanel() {
    const p = state.player;
    panels.log = state.log.map(l => `<div class="log-line">${l.msg}</div>`).join("") || "모험이 아직 시작되지 않았습니다.";
    if (!p) {
      panels.quest = panels.inv = panels.codex = panels.hook = "";
      return;
    }
    panels.quest = p.quests.map(q =>
      `<div class="quest${q.done ? " done" : ""}${q.kind === "special" ? " special" : ""}"><span class="tag">${q.kind === "main" ? "메인" : q.kind === "special" ? "특별 · 재앙" : "서브"}</span><br><b>${q.title}</b><br>${q.desc}<br>진행 ${q.cur}/${q.need}</div>`
    ).join("");
    const rows = Object.entries(p.inv).filter(([, n]) => n > 0);
    panels.inv = rows.map(([k, n]) =>
      `<div class="item"><b>${ITEMS[k].name}</b> ×${n} <button data-use="${k}">사용</button></div>`
    ).join("") || "가방이 비었습니다.";
    const knownN = p.codex.size;
    panels.codex = `<div class="item">마을급 도감 ${knownN} / 80</div>` +
      ["정석", "권속", "칭호", "형상"].map(kind => {
        const list = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === kind).map(id => {
          const m = MONSTERS[id];
          return p.codex.has(id) ? `<div class="codex"><b>${m.name}</b></div>` : `<div class="codex">??? · ${kind}</div>`;
        }).join("");
        return `<div class="item"><b>${kind}</b></div>` + list;
      }).join("");
    const ids = [...p.hooks];
    panels.hook = ids.length
      ? ids.map(id => `<div class="codex"><b>${HOOKS[id].title}</b><br>${HOOKS[id].line}</div>`).join("")
      : "아직 심긴 흔적이 없다.";
    const body = document.getElementById("win-body");
    if (body && !document.getElementById("win-modal").classList.contains("hidden")) {
      const t = document.getElementById("win-title").dataset.tab;
      if (t) fillModal(t);
    }
  }

  function fillModal(tab) {
    const titles = { log: "로그", quest: "퀘스트", inv: "장비와 가방", codex: "도감", hook: "흔적" };
    document.getElementById("win-title").textContent = titles[tab] || tab;
    document.getElementById("win-title").dataset.tab = tab;
    const body = document.getElementById("win-body");
    body.innerHTML = panels[tab] || "";
    body.querySelectorAll("button[data-use]").forEach(b => b.onclick = () => { useItem(b.dataset.use); fillModal("inv"); });
  }

  document.querySelectorAll(".dock button").forEach(btn => {
    btn.onclick = () => {
      renderPanel();
      document.getElementById("win-modal").classList.remove("hidden");
      fillModal(btn.dataset.open);
    };
  });
  document.getElementById("win-close").onclick = () => document.getElementById("win-modal").classList.add("hidden");


  function newPlayer(story) {
    return {
      name: "접힌 자리의 여행자",
      x: 8, y: 8, vx: 0, vy: 0, facing: 0,
      lv: 1, xp: 0, need: 20,
      hp: 28, maxHp: 28, mp: 12, maxMp: 12,
      atk: 6, def: 1, gold: 15,
      inv: { herb: 2, rusty_sword: 1 },
      quests: [
        { id: "start", kind: "main", title: "길려진 해의 기성", desc: "북동쪽 숲의 버려진 던전 3층을 조사한다. 형상은 아직 없다.", cur: 0, need: 1, done: false },
        { id: "hooks", kind: "side", title: "심기만 하는 말", desc: "흔적 8. 지금은 풀지 않는다.", cur: 0, need: 8, done: false },
        { id: "collect", kind: "side", title: "일곱이 아니라 셋", desc: "입구 파편 3.", cur: 0, need: 3, done: false },
        { id: "hunt", kind: "side", title: "제단의 잔액", desc: "잔재 8.", cur: 0, need: 8, done: false },
        { id: "scar", kind: "side", title: "접힌 자국의 약", desc: "촌장에게 약초 1. 아무 일도 없다.", cur: 0, need: 1, done: false },
        { id: "well", kind: "special", title: "우물이 사람을 삼킨다", desc: "갈래 우물에 파편 1.", cur: 0, need: 1, done: false },
        { id: "sky", kind: "special", title: "하늘 구멍이 낮아진다", desc: "내려온 조각을 신유로 식힌다.", cur: 0, need: 1, done: false },
      ],
      codex: new Set(),
      hooks: new Set(),
      story: story.id,
      relic: null,
      dungeon: null,
      nights: 0,
      disasters: { well: "idle", sky: "idle" },
      burned: false,
      heraldGone: false,
    };
  }

  function makeMap(kind, floor) {
    const cols = kind === "town" ? 30 : 24, rows = kind === "town" ? 20 : 16;
    const tiles = [];
    for (let y = 0; y < rows; y++) {
      tiles[y] = [];
      for (let x = 0; x < cols; x++) {
        const wall = x === 0 || y === 0 || x === cols - 1 || y === rows - 1;
        tiles[y][x] = wall ? 1 : 0;
      }
    }
    if (kind === "town") {
      for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) {
        tiles[y][x] = (x >= 16 && y <= 9) ? 5 : 0;
      }
      for (let y = 10; y < 15; y++) for (let x = 4; x < 10; x++) {
        if (y === 10 || y === 14 || x === 4 || x === 9) tiles[y][x] = 2;
      }
      tiles[14][6] = 6; tiles[14][7] = 6;
      for (let x = 11; x < 16; x++) tiles[12][x] = 3;
      const path = [[12,11],[13,10],[14,10],[15,9],[16,9],[17,8],[18,7],[19,6],[20,6],[21,5],[22,5],[23,4],[24,4],[25,3],[25,3]];
      path.forEach(([x, y]) => { if (tiles[y]) tiles[y][x] = 6; });
      tiles[2][26] = 7; tiles[3][26] = 7; tiles[2][25] = 7;
    } else {
      for (let i = 0; i < 28 + floor * 4; i++) {
        const x = 2 + ((i * 7 + floor * 3) % (cols - 4));
        const y = 2 + ((i * 11 + floor * 5) % (rows - 4));
        if (!(x === 8 && y === 8)) tiles[y][x] = 1;
      }
      for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) {
        if (tiles[y][x] === 1) {
          const open = [[1,0],[-1,0],[0,1],[0,-1]].some(([dx, dy]) => tiles[y + dy]?.[x + dx] === 0);
          if (!open) tiles[y][x] = 0;
        }
      }
    }
    return { cols, rows, tiles, kind };
  }

  function spawnFloor() {
    const p = state.player;
    const town = state.floor === 0;
    state.map = makeMap(town ? "town" : "dungeon", state.floor);
    if (town) { p.x = 7; p.y = 12; } else { p.x = 8; p.y = 8; }
    state.npcs = [];
    state.enemies = [];
    state.chests = [];
    if (town) {
      if (p.nights >= 2) {
        if (p.disasters.well !== "done") { p.disasters.well = "fail"; p.heraldGone = true; }
        if (p.disasters.sky !== "done") { p.disasters.sky = "fail"; p.burned = true; }
      }
      state.npcs = [
        { x: 5, y: 5, name: "잔신의 촌장", talk: townTalk },
        { x: 14, y: 5, name: "파편 수집가", talk: collectorTalk },
        { x: 18, y: 11, name: "재의 왕좌", talk: () => enterDungeon("ember") },
        { x: 17, y: 13, name: "이름 없는 해안", talk: () => enterDungeon("tide") },
        { x: 15, y: 12, name: "뿌리의 속삭임", talk: () => enterDungeon("root") },
        { x: 2, y: 10, name: "달력 돌", talk: () => plantTalk("H03", "달력 돌", ["새겨진 계절이 하루를 건너뛰었다.", "누가 달력을 씹는지, 돌은 말하지 않는다."]) },
        { x: 19, y: 3, name: "궤도 광인", talk: madTalk },
        { x: 8, y: 13, name: "먼지의 부랑", talk: () => plantTalk("H05", "먼지의 부랑", ["이 흙은 이 땅이 아니다. 항로에서 떨어졌다.", "별 이름이 있는데, 너희 지도에는 칸이 없다."]) },
        { x: 16, y: 8, name: "등대 유품", talk: () => plantTalk("H06", "등대 유품", ["나선. 팔이 일곱. 등대지기 스케치라 적혀 있다.", "바다는 이 그림에 없다."]) },
        { x: 3, y: 13, name: "실 쥔 아이", talk: () => plantTalk("H07", "실 쥔 아이", ["먼 불빛들을 잇는 실이야.", "끊으면 떨어진대. 어디로는 안 가르쳐 줬어."]) },
        { x: 12, y: 2, name: "낙서 우물", talk: () => plantTalk("H08", "낙서 우물", ["1=1이 아니라고 적혀 있다.", "지워도 밤에 다시 생긴다."]) },
        { x: 20, y: 7, name: "갈래 우물", talk: wellTalk },
        { x: 7, y: 2, name: "축이 빈 비석", talk: () => plantTalk("H10", "축이 빈 비석", ["글이 읽히다가 방향을 바꾼다.", "…", "문장이 비었다."]) },
        { x: 1, y: 7, name: "문 없는 문짝", talk: () => plantTalk("H11", "문 없는 문짝", ["닫혀 있다. 문이 없다.", "이름은 적혀 있지 않다."]) },
      ];
      if (!p.heraldGone) {
        state.npcs.push({ x: 10, y: 11, name: "왕도의 전령", talk: heraldTalk });
      } else {
        state.npcs.push({ x: 10, y: 11, name: "빈 자리", talk: () => openDialog("빈 자리", ["전령의 이름만 지워져 있다. 우물이 삼켰다."]) });
      }
      if (p.disasters.sky === "open" || p.disasters.sky === "done") {
        state.npcs.push({ x: 11, y: 1, name: "내려온 조각", talk: shardTalk });
      }
      if (p.burned) {
        const m = state.map;
        for (let y = 1; y < 4; y++) for (let x = 8; x < 14; x++) if (m.tiles[y][x] === 0) m.tiles[y][x] = 4;
      }
      state.stairs = null;
    } else {
      const basics = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === "정석");
      const kins = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === "권속");
      const n = 6 + state.floor;
      for (let i = 0; i < n; i++) {
        const pos = emptyTile();
        const rareKin = Math.random() < 0.08;
        const id = rareKin ? kins[rand(0, kins.length - 1)] : basics[rand(0, basics.length - 1)];
        state.enemies.push({ id, x: pos.x, y: pos.y, hp: MONSTERS[id].hp, alive: true, t: Math.random() * 100 });
      }
      if (state.floor >= 3 && Math.random() < 0.2) {
        const pos = emptyTile();
        const tid = Math.random() < 0.5 ? "titled_echo" : "titled_dust";
        state.enemies.push({ id: tid, x: pos.x, y: pos.y, hp: MONSTERS[tid].hp, alive: true, t: 0 });
      }
      if (state.floor >= 3 && state.player.dungeon === "haesung") {
        const pos = emptyTile();
        state.npcs.push({ x: pos.x, y: pos.y, name: "지워진 해의 자리", talk: () => {
          bumpQuest("start", 1);
          plantHook("H16");
          openDialog("지워진 해의 자리", [
            "해가 길려 나갔다. 성만 남았다.",
            "형상은 여기 없다. 버려진 던전이다. 메인 조사는 여기까지.",
          ]);
        }});
      }
      for (let i = 0; i < 2; i++) {
        const pos = emptyTile();
        state.chests.push({ x: pos.x, y: pos.y, open: false, item: i ? "ether" : "herb" });
      }
      if (state.floor === 2 && state.player.dungeon === "tide" && !state.player.inv.god_thread) {
        const pos = emptyTile();
        state.npcs.push({ x: pos.x, y: pos.y, name: "개연의 제단", talk: () => {
          if (state.player.inv.god_thread) {
            openDialog("개연의 제단", ["이미 파편을 쥐고 있다. 개연은 하나뿐이다."]);
          } else {
            addItem("god_thread");
            openDialog("개연의 제단", ["신의 개연 파편. 마을급에는 이것 하나다."]);
          }
        }});
      }
      state.stairs = emptyTile();
    }
  }

  function emptyTile() {
    const m = state.map;
    for (let k = 0; k < 80; k++) {
      const x = 2 + Math.floor(Math.random() * (m.cols - 4));
      const y = 2 + Math.floor(Math.random() * (m.rows - 4));
      if (m.tiles[y][x] === 0 && !(x === 8 && y === 8) && !occupied(x, y)) return { x, y };
    }
    return { x: 10, y: 10 };
  }
  function occupied(x, y) {
    return state.enemies.some(e => e.alive && e.x === x && e.y === y) ||
      state.chests.some(c => c.x === x && c.y === y) ||
      state.npcs.some(n => n.x === x && n.y === y);
  }

  function plantHook(id) {
    const p = state.player;
    if (!p || p.hooks.has(id)) return;
    p.hooks.add(id);
    log("흔적: " + HOOKS[id].title, true);
    bumpQuest("hooks", p.hooks.size);
  }
  function plantTalk(id, who, lines) {
    plantHook(id);
    if (id === "H10") plantHook("H15");
    openDialog(who, lines);
  }
  function townTalk() {
    plantHook("H01");
    plantHook("H12");
    const p = state.player;
    if ((p.inv.herb || 0) > 0 && !p.quests.find(q => q.id === "scar").done) {
      p.inv.herb--;
      bumpQuest("scar", 1);
      openDialog("잔신의 촌장", [
        "약초를 바쳤군. …아무 일도 없다.",
        "지금은 안 듣는다. 접힌 자국은 나중에야 약이 된다.",
      ]);
      return;
    }
    openDialog("잔신의 촌장", [
      "여긴 아스안이다. 처음은 여기서 뜬다.",
      "북동쪽 숲에 버려진 던전이 있다. 「길려진 해의 기성」. 해가 길려 나간 성.",
      "왕도 전령, 우물, 하늘의 구멍은 재앙이다. 메인은 기성이다.",
    ]);
  }
  function heraldTalk() {
    plantTalk("H02", "왕도의 전령", [
      "편지를 열면 법령이 손을 탄다.",
      "우물이 밤마다 이름을 삼킨다. 나는 아직 있다. 아직은.",
    ]);
  }
  function madTalk() {
    plantHook("H04");
    const p = state.player;
    if (p.disasters.sky === "idle") {
      p.disasters.sky = "open";
      log("특별 재앙: 하늘 구멍이 낮아진다.", true);
    }
    openDialog("궤도 광인", [
      "구멍이 낮아진다. 북쪽에 조각이 떨어졌다.",
      "신유로 식히지 않으면 땅이 탄다. 행성 이야기가 아니다. 아직은.",
    ]);
    if (state.floor === 0 && !state.npcs.some(n => n.name === "내려온 조각")) {
      state.npcs.push({ x: 11, y: 1, name: "내려온 조각", talk: shardTalk });
    }
  }
  function shardTalk() {
    const p = state.player;
    if (p.disasters.sky === "done") {
      openDialog("내려온 조각", ["식었다. 구멍은 다시 멀다. 완전히는 아니다."]);
      return;
    }
    if ((p.inv.ether || 0) > 0) {
      p.inv.ether--;
      p.disasters.sky = "done";
      bumpQuest("sky", 1);
      openDialog("내려온 조각", ["신유가 열을 접었다. 하늘 구멍은 조금 멀어졌다.", "궤도 제단은 아직 있다. 회수는 행성급."]);
    } else {
      p.hp = Math.max(1, Math.floor(p.hp * 0.5));
      hud();
      openDialog("내려온 조각", ["맨손으로 만졌다. 몸이 반으로 익었다.", "신유(神油)가 필요하다."]);
    }
  }
  function wellTalk() {
    plantHook("H09");
    const p = state.player;
    if (p.disasters.well === "idle") {
      p.disasters.well = "open";
      log("특별 재앙: 우물이 사람을 삼킨다.", true);
    }
    if (p.disasters.well === "done") {
      openDialog("갈래 우물", ["금이 갔다. 지워짐은 멈췄다. 다른 나는 아직 물결에 있다."]);
      return;
    }
    const keys = ["ember_shard", "tide_pearl", "root_seed"];
    const have = keys.find(k => p.inv[k] > 0);
    if (have) {
      p.inv[have]--;
      p.disasters.well = "done";
      bumpQuest("well", 1);
      openDialog("갈래 우물", [
        ITEMS[have].name + "을 제물 대신 던졌다.",
        "우물이 사람을 그만 삼킨다. 금이 간다. 회수는 다중우주.",
      ]);
    } else {
      openDialog("갈래 우물", [
        "메아리가 먼저 대답한다. 아직 묻지 않은 말로.",
        "밤마다 이름이 하나 지워진다. 파편을 제물 대신 던져라.",
      ]);
    }
  }
  function collectorTalk() {
    const p = state.player;
    const keys = ["ember_shard", "tide_pearl", "root_seed"];
    const n = keys.reduce((s, k) => s + (p.inv[k] || 0), 0);
    bumpQuest("collect", n);
    plantHook("H13");
    plantHook("H14");
    openDialog("파편 수집가", [
      "악성은 죽여도 국경 너머에서 다시 핀다. 여긴 형상일 뿐이야.",
      "파편 " + n + "조각. 일곱이면 극의 문이 열린다—고들 하지.",
      "나는 그게 너무 쉽다고 생각하네. 지금은 모으기만 하게.",
    ]);
  }
  function enterDungeon(id) {
    state.player.nights++;
    state.player.dungeon = id;
    state.story = STORIES[0];
    state.floor = 1;
    spawnFloor();
    log("버려진 던전 「길려진 해의 기성」 1층.", true);
  }

  function openDialog(who, lines) {
    state.dialog = { who, lines, i: 0 };
    state.screen = "dialog";
  }

  function bumpQuest(id, cur) {
    const q = state.player.quests.find(q => q.id === id);
    if (!q || q.done) return;
    q.cur = Math.min(q.need, typeof cur === "number" ? cur : q.cur + 1);
    if (q.cur >= q.need) { q.done = true; log("퀘스트 완료: " + q.title, true); state.player.gold += 20; }
    renderPanel();
  }

  function useItem(id) {
    const p = state.player;
    if (!p.inv[id]) return;
    const it = ITEMS[id];
    if (it.type === "heal") {
      p.hp = Math.min(p.maxHp, p.hp + it.val);
      p.inv[id]--;
      log(it.name + "을(를) 사용했다.");
    } else if (it.type === "mana") {
      p.mp = Math.min(p.maxMp, p.mp + it.val);
      p.inv[id]--;
      log(it.name + "을(를) 사용했다.");
    } else {
      log(it.name + "은(는) 사용할 수 없다.");
    }
    hud(); renderPanel();
  }

  function addItem(id, n = 1) {
    state.player.inv[id] = (state.player.inv[id] || 0) + n;
    log(ITEMS[id].name + " 획득 ×" + n, true);
    if (["ember_shard", "tide_pearl", "root_seed"].includes(id)) {
      const keys = ["ember_shard", "tide_pearl", "root_seed"];
      const c = keys.reduce((s, k) => s + (state.player.inv[k] || 0), 0);
      bumpQuest("collect", c);
    }
    if (itRelic(id)) {
      state.player.relic = id;
      bumpQuest("start", 1);
      state.screen = "win";
    }
    renderPanel();
  }
  function itRelic(id) { return ITEMS[id]?.type === "relic"; }

  function startBattle(en) {
    const m = MONSTERS[en.id];
    state.player.codex.add(en.id);
    state.battle = {
      en, m,
      ehp: en.hp,
      log: m.name + "이(가)  apparition!".replace(" apparition!", "나타났다!"),
      turn: "player",
      anim: 0,
    };
    state.screen = "battle";
    renderPanel();
  }

  function battleAct(kind) {
    const b = state.battle, p = state.player;
    if (!b || b.turn !== "player") return;
    let dmg = 0, cost = 0, txt = "";
    if (kind === "atk") { dmg = p.atk + (p.inv.rusty_sword ? 2 : 0) + rand(0, 2); txt = "검을 휘둘렀다!"; }
    if (kind === "skill") {
      cost = 4;
      if (p.mp < cost) { b.log = "마나가 부족하다."; return; }
      p.mp -= cost;
      dmg = p.atk * 2 + rand(1, 4);
      txt = "속성 스킬!";
    }
    if (kind === "item") { useItem("herb"); b.log = "약초를 사용했다."; b.turn = "enemy"; hud(); return; }
    if (kind === "run") {
      if (!b.m.boss && Math.random() < 0.55) { state.screen = "play"; log("도망쳤다."); return; }
      b.log = "도망치지 못했다!"; b.turn = "enemy"; return;
    }
    b.ehp -= dmg;
    b.en.hp = b.ehp;
    b.log = txt + " " + dmg + " 피해.";
    b.anim = 8;
    if (b.ehp <= 0) { winBattle(); return; }
    b.turn = "enemy";
    hud();
  }

  function winBattle() {
    const b = state.battle, p = state.player, m = b.m;
    b.en.alive = false;
    p.xp += m.xp;
    p.gold += 4 + Math.floor(m.xp / 3);
    if (m.drop && Math.random() < (m.boss ? 1 : 0.55)) addItem(m.drop);
    bumpQuest("hunt");
    log(m.name + " 처치. +" + m.xp + " XP", true);
    while (p.xp >= p.need) {
      p.xp -= p.need; p.lv++; p.need = Math.floor(p.need * 1.35);
      p.maxHp += 6; p.maxMp += 3; p.atk += 2; p.hp = p.maxHp; p.mp = p.maxMp;
      log("레벨 업! Lv." + p.lv, true);
    }
    state.screen = itRelic(m.drop) && p.relic ? "win" : "play";
    state.battle = null;
    hud(); renderPanel();
  }

  function enemyTurn() {
    const b = state.battle, p = state.player;
    if (!b || b.turn !== "enemy") return;
    const dmg = Math.max(1, b.m.atk - p.def + rand(0, 2));
    p.hp -= dmg;
    b.log = b.m.name + "의 공격! " + dmg + " 피해.";
    b.turn = "player";
    if (p.hp <= 0) {
      p.hp = 0;
      log("쓰러졌다… 마을에서 눈을 뜬다.", true);
      state.floor = 0;
      p.hp = Math.max(1, Math.floor(p.maxHp * 0.5));
      spawnFloor();
      state.screen = "play";
      state.battle = null;
    }
    hud();
  }

  function rand(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }

  function tryInteract() {
    const p = state.player;
    const nx = Math.round(p.x), ny = Math.round(p.y);
    const npc = state.npcs.find(n => Math.abs(n.x - nx) + Math.abs(n.y - ny) <= 1);
    if (npc) { npc.talk(); return; }
    const ch = state.chests.find(c => !c.open && Math.abs(c.x - nx) + Math.abs(c.y - ny) <= 1);
    if (ch) { ch.open = true; addItem(ch.item); return; }
    if (state.stairs && Math.abs(state.stairs.x - nx) + Math.abs(state.stairs.y - ny) <= 1) {
      if (state.floor < 3) { state.floor++; spawnFloor(); log("다음 층으로 내려갔다.", true); }
      else { state.floor = 0; spawnFloor(); log("마을로 돌아왔다."); }
    }
  }

  function blocked(x, y) {
    const m = state.map;
    const tx = Math.floor(x + 0.4), ty = Math.floor(y + 0.4);
    if (tx < 0 || ty < 0 || tx >= m.cols || ty >= m.rows) return true;
    const t = m.tiles[ty][tx];
    return t === 1 || t === 2 || t === 3;
  }

  window.addEventListener("keydown", e => {
    keys[e.key.toLowerCase()] = true;
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
    if (state.screen === "title" && (e.key === "Enter" || e.key === " ")) pickStory(Math.max(0, state.hover));
    if (state.screen === "dialog" && (e.key === " " || e.key === "Enter" || e.key === "e")) {
      state.dialog.i++;
      if (state.dialog.i >= state.dialog.lines.length) { state.screen = "play"; state.dialog = null; }
    }
    if (state.screen === "play") {
      if (e.key === " " || e.key.toLowerCase() === "e") tryInteract();
      if (e.key.toLowerCase() === "i") { renderPanel(); document.getElementById("win-modal").classList.remove("hidden"); fillModal("inv"); }
      if (e.key.toLowerCase() === "q") { renderPanel(); document.getElementById("win-modal").classList.remove("hidden"); fillModal("quest"); }
    }
    if (state.screen === "battle") {
      if (e.key === "1" || e.key === " ") battleAct("atk");
      if (e.key === "2") battleAct("skill");
      if (e.key === "3") battleAct("item");
      if (e.key === "4" || e.key === "Escape") battleAct("run");
    }
    if (state.screen === "win" && (e.key === "Enter" || e.key === " ")) {
      state.screen = "title"; state.player = null; hud();
    }
  });
  window.addEventListener("keyup", e => { keys[e.key.toLowerCase()] = false; });

  canvas.addEventListener("mousemove", e => {
    if (state.screen !== "title") return;
    const r = canvas.getBoundingClientRect();
    const x = (e.clientX - r.left) * (W / r.width);
    const y = (e.clientY - r.top) * (H / r.height);
    state.hover = -1;
    STORIES.forEach((_, i) => {
      const bx = 80, by = 180 + i * 100, bw = 800, bh = 84;
      if (x >= bx && x <= bx + bw && y >= by && y <= by + bh) state.hover = i;
    });
  });
  canvas.addEventListener("click", e => {
    if (state.screen === "title" && state.hover >= 0) pickStory(state.hover);
    if (state.screen === "battle") {
      const r = canvas.getBoundingClientRect();
      const x = (e.clientX - r.left) * (W / r.width);
      const y = (e.clientY - r.top) * (H / r.height);
      const acts = ["atk", "skill", "item", "run"];
      acts.forEach((a, i) => {
        const bx = 80 + i * 200, by = 450;
        if (x >= bx && x <= bx + 180 && y >= by && y <= by + 50) battleAct(a);
      });
    }
  });

  function pickStory(i) {
    state.story = STORIES[i] || STORIES[0];
    state.player = newPlayer(state.story);
    state.floor = 0;
    spawnFloor();
    state.screen = "play";
    log("스토리 「" + state.story.title + "」를 선택했다.", true);
    log(state.story.blurb);
    hud(); renderPanel();
  }

  function update(dt) {
    state.time += dt;
    if (state.screen !== "play") return;
    const p = state.player;
    let dx = 0, dy = 0;
    if (keys["w"] || keys["arrowup"]) dy -= 1;
    if (keys["s"] || keys["arrowdown"]) dy += 1;
    if (keys["a"] || keys["arrowleft"]) dx -= 1;
    if (keys["d"] || keys["arrowright"]) dx += 1;
    const sp = 4.2 * dt;
    if (dx || dy) {
      const len = Math.hypot(dx, dy);
      dx /= len; dy /= len;
      if (!blocked(p.x + dx * sp, p.y)) p.x += dx * sp;
      if (!blocked(p.x, p.y + dy * sp)) p.y += dy * sp;
    }
    state.enemies.forEach(en => {
      if (!en.alive) return;
      en.t += dt;
      if (en.t > 1.2) {
        en.t = 0;
        const step = [[1, 0], [-1, 0], [0, 1], [0, -1]][rand(0, 3)];
        const nx = en.x + step[0], ny = en.y + step[1];
        if (!blocked(nx, ny) && !occupied(nx, ny)) { en.x = nx; en.y = ny; }
      }
      if (Math.abs(en.x - p.x) < 0.7 && Math.abs(en.y - p.y) < 0.7) startBattle(en);
    });
    hud();
  }

  function drawMob(ctx, x, y, m) {
    if (!m) return;
    const r = m.boss ? 16 : m.titled ? 13 : 10;
    ctx.fillStyle = m.color;
    ctx.beginPath();
    if (m.shape === "tri") {
      ctx.moveTo(x, y - r); ctx.lineTo(x + r, y + r); ctx.lineTo(x - r, y + r); ctx.closePath();
    } else if (m.shape === "sq") {
      ctx.rect(x - r, y - r, r * 2, r * 2);
    } else if (m.shape === "dia") {
      ctx.moveTo(x, y - r); ctx.lineTo(x + r, y); ctx.lineTo(x, y + r); ctx.lineTo(x - r, y); ctx.closePath();
    } else if (m.shape === "wolf") {
      ctx.ellipse(x, y, r + 2, r - 2, 0, 0, Math.PI * 2);
    } else {
      ctx.arc(x, y, r, 0, Math.PI * 2);
    }
    ctx.fill();
    if (m.kind === "권속") {
      ctx.strokeStyle = "#e6c15a";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, r + 4, 0, Math.PI * 2);
      ctx.stroke();
      ctx.lineWidth = 1;
    }
    if (m.kind === "칭호") {
      ctx.strokeStyle = "#fff3a0";
      ctx.lineWidth = 3;
      ctx.strokeRect(x - r - 3, y - r - 3, (r + 3) * 2, (r + 3) * 2);
      ctx.lineWidth = 1;
    }
    if (m.boss) {
      ctx.strokeStyle = "#c44536";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(x, y, r + 6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.lineWidth = 1;
    }
  }

  function pal() {
    const s = state.story?.id;
    if (s === "haesung") return { floor: "#1c2228", wall: "#0c1014", accent: "#8a9aa8", grass: "#3a4a30" };
    return { floor: "#1c2228", wall: "#0c1014", accent: "#8a9aa8", grass: "#3a4a30" };
  }

  function draw() {
    ctx.fillStyle = "#08070c";
    ctx.fillRect(0, 0, W, H);
    if (state.screen === "title") return drawTitle();
    if (state.screen === "battle") return drawBattle();
    if (state.screen === "win") return drawWin();
    drawWorld();
    if (state.screen === "dialog") drawDialog();
  }

  function drawTitle() {
    ctx.fillStyle = "#efe8d8";
    ctx.font = "bold 42px serif";
    ctx.fillText("극  ·  에코 오브 아스안", 80, 90);
    ctx.font = "16px sans-serif";
    ctx.fillStyle = "#9a8f78";
    ctx.fillText("마을에서 우주·다중차원을 지나, 그 위 극까지. 신은 가능과 불가능의 기초. 악성 일곱이 급마다 핀다.", 80, 128);
    STORIES.forEach((s, i) => {
      const y = 180 + i * 100;
      ctx.fillStyle = state.hover === i ? s.color : "#1a1822";
      ctx.fillRect(80, y, 800, 84);
      ctx.strokeStyle = s.color;
      ctx.strokeRect(80, y, 800, 84);
      ctx.fillStyle = "#efe8d8";
      ctx.font = "bold 22px serif";
      ctx.fillText(s.title, 110, y + 36);
      ctx.font = "14px sans-serif";
      ctx.fillStyle = "#cfc6b4";
      ctx.fillText(s.blurb, 110, y + 62);
    });
  }

  function tileColor(t, x, y, grass) {
    if (t === 1) return "#3a322c";
    if (t === 2) return "#6a5a48";
    if (t === 3) return "#2a6a88";
    if (t === 4) return "#2a1810";
    if (t === 5) return "#245028";
    if (t === 6) return "#9a8a72";
    if (t === 7) return "#7a8894";
    const n = (x * 13 + y * 7) % 5;
    return n === 0 ? "#4a8a3a" : n === 1 ? "#3f7a34" : grass;
  }

  function drawWorld() {
    const m = state.map, p = state.player, c = pal();
    const ox = Math.floor(W / 2 - p.x * TILE - TILE / 2);
    const oy = Math.floor(H / 2 - p.y * TILE - TILE / 2);
    ctx.fillStyle = "#1a3a18";
    ctx.fillRect(0, 0, W, H);
    for (let y = 0; y < m.rows; y++) {
      for (let x = 0; x < m.cols; x++) {
        const t = m.tiles[y][x];
        const px = ox + x * TILE, py = oy + y * TILE;
        ctx.fillStyle = tileColor(t, x, y, m.kind === "town" ? "#45883a" : c.floor);
        ctx.fillRect(px, py, TILE, TILE);
        if (t === 0 || t === 5) {
          ctx.fillStyle = "rgba(255,255,255,0.06)";
          ctx.fillRect(px + ((x * 5) % 20), py + ((y * 3) % 20), 3, 3);
        }
        if (t === 6) {
          ctx.strokeStyle = "rgba(0,0,0,0.15)";
          ctx.strokeRect(px + 1, py + 1, TILE - 2, TILE - 2);
        }
        if (t === 2) {
          ctx.fillStyle = "#8a3a28";
          ctx.fillRect(px + 4, py, TILE - 8, 8);
          ctx.fillStyle = "#c9a227";
          ctx.fillRect(px + 12, py + 14, 8, 10);
        }
        if (t === 5 && (x + y) % 2 === 0) {
          ctx.fillStyle = "#1a3a14";
          ctx.beginPath();
          ctx.arc(px + 16, py + 14, 12, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#5a3a18";
          ctx.fillRect(px + 14, py + 20, 4, 10);
        }
        if (t === 3) {
          ctx.fillStyle = "rgba(180,220,255,0.25)";
          ctx.fillRect(px + 6, py + 10, 14, 4);
        }
      }
    }
    if (state.stairs) {
      ctx.fillStyle = "#c9a227";
      ctx.fillRect(ox + state.stairs.x * TILE + 6, oy + state.stairs.y * TILE + 6, 20, 20);
    }
    state.chests.forEach(ch => {
      ctx.fillStyle = ch.open ? "#5a4030" : "#d4a017";
      ctx.fillRect(ox + ch.x * TILE + 8, oy + ch.y * TILE + 10, 16, 14);
    });
    state.npcs.forEach(n => {
      const nx = ox + n.x * TILE, ny = oy + n.y * TILE;
      ctx.fillStyle = "#3a2418";
      ctx.fillRect(nx + 10, ny + 18, 12, 10);
      ctx.fillStyle = "#f0d8b0";
      ctx.fillRect(nx + 11, ny + 8, 10, 10);
      ctx.fillStyle = "#c9a227";
      ctx.fillRect(nx + 12, ny + 4, 8, 5);
      ctx.fillStyle = "#fff";
      ctx.font = "11px sans-serif";
      ctx.fillText(n.name, nx - 8, ny - 2);
    });
    state.enemies.forEach(en => {
      if (!en.alive) return;
      drawMob(ctx, ox + en.x * TILE + 16, oy + en.y * TILE + 16, MONSTERS[en.id]);
    });
    const px = ox + p.x * TILE, py = oy + p.y * TILE;
    ctx.fillStyle = "#2a4068";
    ctx.fillRect(px + 10, py + 16, 12, 12);
    ctx.fillStyle = "#f0d0a8";
    ctx.fillRect(px + 11, py + 8, 10, 10);
    ctx.fillStyle = "#3a2418";
    ctx.fillRect(px + 12, py + 6, 8, 4);
    ctx.fillStyle = "#c44536";
    ctx.fillRect(px + 14, py + 18, 4, 6);
    drawMini(m, p);
  }

  function drawMini(m, p) {
    const mm = document.getElementById("minimap");
    if (!mm) return;
    const mx = mm.getContext("2d");
    const s = mm.width / Math.max(m.cols, m.rows);
    mx.fillStyle = "#142010";
    mx.fillRect(0, 0, mm.width, mm.height);
    for (let y = 0; y < m.rows; y++) for (let x = 0; x < m.cols; x++) {
      const t = m.tiles[y][x];
      mx.fillStyle = t === 1 ? "#222" : t === 5 ? "#1a4a20" : t === 6 ? "#aaa" : t === 3 ? "#246" : t === 2 ? "#642" : t === 7 ? "#89a" : "#3a7a30";
      mx.fillRect(x * s, y * s, s, s);
    }
    mx.fillStyle = "#fff";
    mx.fillRect(p.x * s, p.y * s, s + 1, s + 1);
  }

  function drawDialog() {
    const d = state.dialog;
    ctx.fillStyle = "rgba(8,7,12,0.85)";
    ctx.fillRect(40, H - 160, W - 80, 130);
    ctx.strokeStyle = pal().accent;
    ctx.strokeRect(40, H - 160, W - 80, 130);
    ctx.fillStyle = "#e6c15a";
    ctx.font = "bold 16px serif";
    ctx.fillText(d.who, 60, H - 128);
    ctx.fillStyle = "#efe8d8";
    ctx.font = "16px sans-serif";
    ctx.fillText(d.lines[d.i], 60, H - 92);
    ctx.fillStyle = "#9a8f78";
    ctx.font = "12px sans-serif";
    ctx.fillText("스페이스로 계속", 60, H - 50);
  }

  function drawBattle() {
    const b = state.battle, p = state.player, c = pal();
    ctx.fillStyle = c.floor;
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = b.m.color;
    const shake = b.anim > 0 ? (b.anim--, 6) : 0;
    ctx.beginPath();
    ctx.arc(W / 2 + shake, 180, b.m.boss ? 70 : 48, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#efe8d8";
    ctx.font = "bold 22px serif";
    ctx.textAlign = "center";
    ctx.fillText(b.m.name, W / 2, 80);
    ctx.font = "14px sans-serif";
    ctx.fillText("HP " + Math.max(0, b.ehp) + " / " + b.m.hp, W / 2, 270);
    ctx.fillStyle = "#2a1c1c";
    ctx.fillRect(W / 2 - 140, 284, 280, 12);
    ctx.fillStyle = "#c44536";
    ctx.fillRect(W / 2 - 140, 284, 280 * Math.max(0, b.ehp) / b.m.hp, 12);
    ctx.textAlign = "left";
    ctx.fillStyle = "#efe8d8";
    ctx.font = "16px sans-serif";
    ctx.fillText(b.log, 80, 360);
    const labels = ["1 공격", "2 스킬 (MP4)", "3 아이템", "4 도망"];
    labels.forEach((lb, i) => {
      ctx.fillStyle = "#1a1822";
      ctx.fillRect(80 + i * 200, 450, 180, 50);
      ctx.strokeStyle = c.accent;
      ctx.strokeRect(80 + i * 200, 450, 180, 50);
      ctx.fillStyle = "#efe8d8";
      ctx.fillText(lb, 100 + i * 200, 480);
    });
  }

  function drawWin() {
    ctx.fillStyle = "#efe8d8";
    ctx.font = "bold 36px serif";
    ctx.fillText("악성을 봉인했다", 80, 160);
    ctx.font = "18px sans-serif";
    ctx.fillStyle = pal().accent;
    ctx.fillText(state.story.title + " — " + ITEMS[state.player.relic].name, 80, 220);
    ctx.fillStyle = "#9a8f78";
    ctx.font = "16px sans-serif";
    ctx.fillText("극이 한번 눈을 떴다. 침묵은 그대로다. 세 입구를 모두 지나면 극의 문이 열린다.", 80, 270);
    ctx.fillText("Enter — 다른 입구로.", 80, 310);
  }

  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (state.screen === "battle" && state.battle?.turn === "enemy") {
      state.battle._cd = (state.battle._cd || 0) + dt;
      if (state.battle._cd > 0.7) { state.battle._cd = 0; enemyTurn(); }
    }
    update(dt);
    draw();
    requestAnimationFrame(loop);
  }
  renderPanel();
  requestAnimationFrame(loop);
})();
