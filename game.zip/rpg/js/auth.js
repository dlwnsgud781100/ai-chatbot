(() => {
  const GMAIL = /^[a-zA-Z0-9._%+-]+@gmail\.com$/i;
  const KEY_USERS = "echo_users_v1";
  const KEY_SESS = "echo_session_v1";

  function users() {
    try { return JSON.parse(localStorage.getItem(KEY_USERS) || "[]"); }
    catch { return []; }
  }
  function saveUsers(list) { localStorage.setItem(KEY_USERS, JSON.stringify(list)); }

  async function hash(pw, salt) {
    const enc = new TextEncoder().encode(salt + ":" + pw);
    const buf = await crypto.subtle.digest("SHA-256", enc);
    return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
  }
  function salt() {
    const a = new Uint8Array(8);
    crypto.getRandomValues(a);
    return [...a].map(b => b.toString(16).padStart(2, "0")).join("");
  }

  function session() {
    try { return JSON.parse(localStorage.getItem(KEY_SESS) || "null"); }
    catch { return null; }
  }
  function setSession(u) {
    const s = { email: u.email, name: u.name };
    localStorage.setItem(KEY_SESS, JSON.stringify(s));
    window.ECHO_USER = s;
  }

  function showErr(el, msg) { el.textContent = msg || ""; }

  function openApp() {
    document.getElementById("auth-gate").classList.add("hidden");
    document.getElementById("app").classList.remove("locked");
    const n = document.getElementById("account-name");
    if (n && window.ECHO_USER) n.textContent = window.ECHO_USER.name + " · " + window.ECHO_USER.email;
  }

  async function doSignup() {
    const err = document.getElementById("auth-err");
    const email = document.getElementById("su-email").value.trim().toLowerCase();
    const pw = document.getElementById("su-pw").value;
    const pw2 = document.getElementById("su-pw2").value;
    const name = document.getElementById("su-name").value.trim();
    if (!GMAIL.test(email)) return showErr(err, "Gmail 주소만 사용할 수 있습니다. (예: name@gmail.com)");
    if (name.length < 2 || name.length > 12) return showErr(err, "플레이어 이름은 2~12자로 정하세요.");
    if (pw.length < 6) return showErr(err, "비밀번호는 6자 이상.");
    if (pw !== pw2) return showErr(err, "비밀번호가 서로 다릅니다.");
    const list = users();
    if (list.some(u => u.email === email)) return showErr(err, "이미 가입된 Gmail입니다. 로그인하세요.");
    const s = salt();
    list.push({ email, name, salt: s, hash: await hash(pw, s), created: Date.now() });
    saveUsers(list);
    setSession(list[list.length - 1]);
    openApp();
  }

  async function doLogin() {
    const err = document.getElementById("auth-err");
    const email = document.getElementById("li-email").value.trim().toLowerCase();
    const pw = document.getElementById("li-pw").value;
    if (!GMAIL.test(email)) return showErr(err, "Gmail 주소로 로그인하세요.");
    const u = users().find(x => x.email === email);
    if (!u) return showErr(err, "가입되지 않은 계정입니다. 회원가입을 하세요.");
    if (await hash(pw, u.salt) !== u.hash) return showErr(err, "비밀번호가 틀렸습니다.");
    setSession(u);
    openApp();
  }

  function tab(which) {
    document.getElementById("form-login").classList.toggle("hidden", which !== "login");
    document.getElementById("form-signup").classList.toggle("hidden", which !== "signup");
    document.getElementById("tab-login").classList.toggle("on", which === "login");
    document.getElementById("tab-signup").classList.toggle("on", which === "signup");
    showErr(document.getElementById("auth-err"), "");
  }

  window.echoLogout = () => {
    localStorage.removeItem(KEY_SESS);
    window.ECHO_USER = null;
    location.reload();
  };

  window.addEventListener("DOMContentLoaded", () => {
    document.getElementById("tab-login").onclick = () => tab("login");
    document.getElementById("tab-signup").onclick = () => tab("signup");
    document.getElementById("btn-login").onclick = () => doLogin().catch(() => showErr(document.getElementById("auth-err"), "로그인에 실패했습니다."));
    document.getElementById("btn-signup").onclick = () => doSignup().catch(() => showErr(document.getElementById("auth-err"), "가입에 실패했습니다."));
    const s = session();
    if (s && s.email) { window.ECHO_USER = s; openApp(); }
  });
})();
