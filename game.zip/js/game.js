(() => {
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  const TILE = 32;
  const keys = Object.create(null);
  ctx.imageSmoothingEnabled = false;

  const GFX = { on: false };
  Assets.onReady(ok => { GFX.on = ok; if (ok && state.map) buildLayer(); });

  const STORIES = [
    {
      id: "haesung",
      title: "길려진 해의 기성",
      blurb: "아스안 북동쪽 숲의 버려진 던전. 해가 길려 나간 성.",
      color: "#6a7a88",
    },
  ];

  /* ── 지역(Region) ─────────────────────────────
   * 급 = 주인공이 힘을 미치는 영향력 범위.
   * 마을급 → 국가급 → … → 극. 스토리 진행에 따라 지역이 열린다. */
  const REGIONS = [
    { id: "asan",    name: "아스안 마을",     grade: "마을급", desc: "시작 마을. 세계의 남서쪽 끝.", arrive: { x: 7, y: 12 } },
    { id: "forest",  name: "아스안 북동 숲",  grade: "마을급", desc: "마을에서 북동쪽. 숲 끝에 버려진 성이 있다.", arrive: { x: 2, y: 14 } },
    { id: "haesung", name: "길려진 해의 기성", grade: "마을급", desc: "숲 끝의 던전. 입구가 셋이다.", needVisit: true, arrive: { x: 13, y: 5, atGates: true } },
    { id: "capital", name: "왕도",           grade: "국가급", desc: "악성이 국교가 된 곳. 나라 이름은 아직 없다.", locked: true, lockReason: "국가급 영향력이 필요하다" },
    { id: "border",  name: "국경 너머",       grade: "국가급", desc: "악성은 죽어도 이곳에서 다시 핀다.", locked: true, lockReason: "국가급 영향력이 필요하다" },
  ];
  function currentRegionId() {
    return state.area === "town" ? "asan" : state.area === "forest" ? "forest" : "haesung";
  }
  function regionUnlocked(r) {
    if (r.locked) return false;
    if (r.needVisit) return !!(state.player && state.player.visited.has(r.id));
    return true;
  }
  /* 페이드 이동 */
  function startTravel(run) {
    if (state.pendingTravel) return;
    state.pendingTravel = { t: 0, run, done: false };
  }
  function travelFromModal(id) {
    const r = REGIONS.find(x => x.id === id);
    if (!r) return;
    if (!regionUnlocked(r)) { toast("아직 갈 수 없다"); return; }
    if (id === currentRegionId()) { toast("이미 여기다"); return; }
    document.getElementById("win-modal").classList.add("hidden");
    startTravel(() => {
      const p = state.player;
      if (id === "asan") { state.area = "town"; state.floor = 0; spawnFloor(); }
      else if (id === "forest") { state.area = "forest"; state.floor = 0; spawnFloor(); }
      else if (id === "haesung") { state.area = "forest"; state.floor = 0; spawnFloor(); }
      const a = r.arrive || { x: 7, y: 12 };
      p.x = a.x; p.y = a.y;
      p.visited.add(id);
      log("지역 이동: " + r.name + ((r.arrive && r.arrive.atGates) ? " (입구 앞)" : ""), true);
      hud();
    });
  }

  const ITEMS = {
    herb: { name: "제단 약초", type: "heal", val: 12 },
    ether: { name: "신유(神油)", type: "mana", val: 8 },
    ember_shard: { name: "식지 않는 재", type: "key" },
    tide_pearl: { name: "거울 파편", type: "key" },
    root_seed: { name: "금이 간 잔", type: "key" },
    wrath_blade: { name: "금 간 칼날", type: "key" },
    envy_eye: { name: "거꾸로 눈", type: "key" },
    glutton_seed: { name: "끝없는 씨", type: "key" },
    sloth_sand: { name: "멈춘 모래", type: "key" },
    rusty_sword: { name: "잔신의 녹슨 검", type: "atk", val: 2 },
    relic_crown: { name: "색욕·분노의 봉인", type: "relic" },
    relic_name: { name: "교만·질투의 봉인", type: "relic" },
    relic_dream: { name: "탐·포·면의 봉인", type: "relic" },
    god_thread: { name: "신의 개연 파편", type: "key" },
  };

  const HOOKS = {
    H01: { title: "국교가 된 악성", line: "왕도가 악성을 법으로 섬긴다. 나라 이름은 아직 없다." },
    H02: { title: "미개봉 봉랍", line: "전령의 편지: 「법령이 사람을 먹는다」. 봉인을 열 손이 없다." },
    H03: { title: "건너뛴 계절", line: "달력 돌의 숫자가 하루를 삼켰다. 세계가 달력을 씹는 중." },
    H04: { title: "하늘의 구멍", line: "광인이 궤도 제단을 말한다. 마을은 헛소리로 듣는다." },
    H05: { title: "지도에 없는 먼지", line: "다른 땅에서 온 먼지. 항로라는 낱말만 남았다." },
    H06: { title: "나선 스케치", line: "등대지기 유품. 바닷가로 오해되는 그림. 팔이 너무 많다." },
    H07: { title: "은하를 잇는 실", line: "아이가 쥔 실. 끊기면 떨어진다고만 했다." },
    H08: { title: "1이 1이 아닌 밤", line: "우물가 낙서. 상수 신전의 예고로 읽히지 않는다." },
    H09: { title: "같은 얼굴의 메아리", line: "갈래 우물에 자신과 다른 자신이 있다." },
    H10: { title: "글이 도는 비석", line: "축이 빈 비석. 의미가 붙었다가 빠진다." },
    H11: { title: "문 없는 문짝", line: "닫혀 있으나 문이 없다. 극의 이름은 적혀 있지 않다." },
    H12: { title: "접힌 자국", line: "여행자의 상처는 칼이 아니다. 세계가 접힌 자리." },
    H13: { title: "다시 피는 종양", line: "악성은 죽어도 국경 너머에서 다시 핀다." },
    H14: { title: "일곱이면 극?", line: "수집가는 파편 일곱이 극의 문을 연다고 한다. 너무 쉽다." },
    H15: { title: "비는 문장", line: "어떤 말은 끝나기 전에 사라진다. …" },
    H16: { title: "길려진 해", line: "기성 3층. 해가 길려 나가고 성만 남았다. 형상은 없었다." },
  };

  const MONSTERS = window.VILLAGE_MONSTERS;

  const state = {
    screen: "title", // title | play | battle | dialog | win
    story: null,
    hover: -1,
    mouse: { x: -1, y: -1 },
    player: null,
    map: null,
    floor: 0,
    npcs: [],
    enemies: [],
    chests: [],
    stairs: null,
    log: [],
    dialog: null,
    battle: null,
    time: 0,
    camera: { x: 0, y: 0 },
    area: "town",      // town | forest | dungeon (아스안 마을 | 북동 숲 | 기성)
    exits: [],         // { x, y, label, run } — 밟으면 이동
    pendingTravel: null, // 페이드 이동 { t, run, done }
    layer: null,       // 정적 타일 레이어 캐시
    layerOX: 64, layerOY: 96,
    fx: { dusts: [], dmgs: [], toasts: [], shake: 0 },
  };

  /* ============ 피드백 ============ */
  function log(msg, imp) {
    state.log.unshift({ msg, imp: !!imp, t: Date.now() });
    if (state.log.length > 40) state.log.pop();
    if (imp) toast(msg);
    renderPanel();
  }
  function toast(msg) {
    state.fx.toasts.push({ msg, t: 0 });
    if (state.fx.toasts.length > 3) state.fx.toasts.shift();
  }
  function puffDust(px, py, n) {
    for (let i = 0; i < (n || 1); i++)
      state.fx.dusts.push({ x: px + (Math.random() * 16 - 8), y: py + (Math.random() * 6 - 3), t: -i * 0.06 });
  }
  function dmgNum(px, py, val, crit) {
    state.fx.dmgs.push({ x: px, y: py, v: val, t: 0, crit: !!crit });
  }
  function shake(n) { state.fx.shake = Math.max(state.fx.shake, n); }

  const panels = { log: "", quest: "", inv: "", codex: "", hook: "", region: "" };

  function hud() {
    const p = state.player;
    const hudEl = document.getElementById("hud");
    if (!p) { hudEl.classList.add("hidden"); return; }
    hudEl.classList.remove("hidden");
    document.getElementById("hud-name").textContent = p.name;
    document.getElementById("hud-lv").textContent = p.lv;
    document.getElementById("hp-fill").style.width = (100 * p.hp / p.maxHp) + "%";
    document.getElementById("hp-text").textContent = p.hp + "/" + p.maxHp;
    document.getElementById("mp-fill").style.width = (100 * p.mp / p.maxMp) + "%";
    document.getElementById("mp-text").textContent = p.mp + "/" + p.maxMp;
    document.getElementById("hud-gold").textContent = p.gold;
    document.getElementById("hud-floor").textContent =
      state.area === "town" ? "아스안 마을" :
      state.area === "forest" ? "아스안 북동 숲" :
      "길려진 해의 기성 " + state.floor + "층";
    const main = p.quests.find(q => q.kind === "main" && !q.locked);
    const spec = p.quests.find(q => q.kind === "special" && !q.done && !q.locked);
    document.getElementById("hud-quest").innerHTML = main
      ? `<b>${main.title}</b> ${main.cur}/${main.need}` + (spec ? `<br>⚠ ${spec.title}` : "")
      : "의뢰 없음 — 잔신의 촌장에게 받아라";
    const hb = document.getElementById("hotbar");
    if (hb) {
      const keys = Object.entries(p.inv).filter(([, n]) => n > 0).slice(0, 8);
      while (keys.length < 8) keys.push(["", 0]);
      hb.innerHTML = keys.map(([k, n], i) =>
        `<div class="slot">${k ? ITEMS[k].name + "<br>×" + n : (i + 1)}</div>`
      ).join("");
    }
  }

  function renderPanel() {
    const p = state.player;
    panels.log = state.log.map(l => `<div class="log-line">${l.msg}</div>`).join("") || "모험이 아직 시작되지 않았습니다.";
    if (!p) {
      panels.quest = panels.inv = panels.codex = panels.hook = panels.region = "";
      return;
    }
    const openQs = p.quests.filter(q => !q.locked);
    panels.quest = openQs.length
      ? openQs.map(q =>
        `<div class="quest${q.done ? " done" : ""}${q.kind === "special" ? " special" : ""}"><span class="tag">${q.kind === "main" ? "메인" : q.kind === "special" ? "특별 · 재앙" : "서브"}</span><br><b>${q.title}</b><br>${q.desc}<br>진행 ${q.cur}/${q.need}</div>`
      ).join("")
      : `<div class="item">진행 중인 의뢰가 없다. <b>잔신의 촌장</b>(마을 북서집)에게 의뢰를 받아라.</div>`;
    const rows = Object.entries(p.inv).filter(([, n]) => n > 0);
    panels.inv = rows.map(([k, n]) =>
      `<div class="item"><b>${ITEMS[k].name}</b> ×${n} <button data-use="${k}">사용</button></div>`
    ).join("") || "가방이 비었습니다.";
    const knownN = p.codex.size;
    panels.codex = `<div class="item">마을급 도감 ${knownN} / 80</div>` +
      ["정석", "권속", "칭호", "형상"].map(kind => {
        const list = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === kind).map(id => {
          const m = MONSTERS[id];
          return p.codex.has(id) ? `<div class="codex"><b>${m.name}</b></div>` : `<div class="codex">??? · ${kind}</div>`;
        }).join("");
        return `<div class="item"><b>${kind}</b></div>` + list;
      }).join("");
    const ids = [...p.hooks];
    panels.hook = ids.length
      ? ids.map(id => `<div class="codex"><b>${HOOKS[id].title}</b><br>${HOOKS[id].line}</div>`).join("")
      : "아직 심긴 흔적이 없다.";
    // 지역 이동
    const cur = currentRegionId();
    panels.region = `<div class="grade-note">영향력 등급 <b>마을급</b> — 주인공이 힘을 미치는 범위가 곧 급이다.<br>마을 → 국가 → 세계 → … → 극.</div>` +
      REGIONS.map(r => {
        const un = regionUnlocked(r);
        const here = r.id === cur;
        const head = `<span class="r-grade">${r.grade}</span><br><b>${r.name}</b>${here ? ' <span class="here">여기</span>' : ""}<br><span class="r-desc">${r.desc}</span>`;
        if (!un) return `<div class="region locked">${head}<br><span class="r-lock">🔒 ${r.lockReason || "아직 갈 수 없다"}</span></div>`;
        if (here) return `<div class="region cur">${head}</div>`;
        return `<div class="region"><div>${head}</div><button data-travel="${r.id}">${r.arrive && r.arrive.atGates ? "입구 앞으로" : "이동"}</button></div>`;
      }).join("");
    const body = document.getElementById("win-body");
    if (body && !document.getElementById("win-modal").classList.contains("hidden")) {
      const t = document.getElementById("win-title").dataset.tab;
      if (t) fillModal(t);
    }
  }

  function fillModal(tab) {
    const titles = { log: "로그", quest: "퀘스트", inv: "장비와 가방", codex: "도감", hook: "흔적", region: "지역 이동" };
    document.getElementById("win-title").textContent = titles[tab] || tab;
    document.getElementById("win-title").dataset.tab = tab;
    const body = document.getElementById("win-body");
    body.innerHTML = panels[tab] || "";
    body.querySelectorAll("button[data-use]").forEach(b => b.onclick = () => { useItem(b.dataset.use); fillModal("inv"); });
    body.querySelectorAll("button[data-travel]").forEach(b => b.onclick = () => travelFromModal(b.dataset.travel));
  }

  document.querySelectorAll(".dock button").forEach(btn => {
    btn.onclick = () => {
      renderPanel();
      document.getElementById("win-modal").classList.remove("hidden");
      fillModal(btn.dataset.open);
    };
  });
  document.getElementById("win-close").onclick = () => document.getElementById("win-modal").classList.add("hidden");

  function newPlayer(story) {
    return {
      name: "접힌 자리의 여행자",
      x: 8, y: 8, vx: 0, vy: 0, facing: 0, animT: 0, moving: false,
      lv: 1, xp: 0, need: 20,
      hp: 28, maxHp: 28, mp: 12, maxMp: 12,
      atk: 6, def: 1, gold: 15,
      inv: { herb: 2, rusty_sword: 1 },
      quests: [
        { id: "start", kind: "main", title: "길려진 해의 기성", desc: "북동쪽 숲의 버려진 던전 3층을 조사한다. 형상은 아직 없다.", cur: 0, need: 1, done: false, locked: true },
        { id: "hooks", kind: "side", title: "심기만 하는 말", desc: "흔적 8. 지금은 풀지 않는다.", cur: 0, need: 8, done: false, locked: true },
        { id: "collect", kind: "side", title: "일곱이 아니라 셋", desc: "입구 파편 3.", cur: 0, need: 3, done: false, locked: true },
        { id: "hunt", kind: "side", title: "제단의 잔액", desc: "잔재 8.", cur: 0, need: 8, done: false, locked: true },
        { id: "scar", kind: "side", title: "접힌 자국의 약", desc: "촌장에게 약초 1. 아무 일도 없다.", cur: 0, need: 1, done: false, locked: true },
        { id: "well", kind: "special", title: "우물이 사람을 삼킨다", desc: "갈래 우물에 파편 1.", cur: 0, need: 1, done: false, locked: true },
        { id: "sky", kind: "special", title: "하늘 구멍이 낮아진다", desc: "내려온 조각을 신유로 식힌다.", cur: 0, need: 1, done: false, locked: true },
      ],
      codex: new Set(),
      hooks: new Set(),
      visited: new Set(["asan"]),
      story: story.id,
      relic: null,
      dungeon: null,
      nights: 0,
      disasters: { well: "idle", sky: "idle" },
      burned: false,
      heraldGone: false,
    };
  }

  function makeMap(kind, floor) {
    const cols = kind === "town" ? 30 : kind === "forest" ? 26 : 24;
    const rows = kind === "town" ? 20 : kind === "forest" ? 18 : 16;
    const tiles = [];
    for (let y = 0; y < rows; y++) {
      tiles[y] = [];
      for (let x = 0; x < cols; x++) {
        const wall = x === 0 || y === 0 || x === cols - 1 || y === rows - 1;
        tiles[y][x] = wall ? 1 : 0;
      }
    }
    if (kind === "town") {
      for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) {
        tiles[y][x] = (x >= 16 && y <= 9) ? 5 : 0;
      }
      for (let y = 10; y < 15; y++) for (let x = 4; x < 10; x++) {
        if (y === 10 || y === 14 || x === 4 || x === 9) tiles[y][x] = 2;
      }
      tiles[14][6] = 6; tiles[14][7] = 6;
      for (let x = 11; x < 16; x++) tiles[12][x] = 3;
      const path = [[12,11],[13,10],[14,10],[15,9],[16,9],[17,8],[18,7],[19,6],[20,6],[21,5],[22,5],[23,4],[24,4],[25,3],[25,3]];
      path.forEach(([x, y]) => { if (tiles[y]) tiles[y][x] = 6; });
      // 북동 끝 = 숲으로 가는 출구(8). 양옆 바위.
      tiles[2][26] = 8;
      tiles[3][26] = 7; tiles[2][25] = 7;
    } else if (kind === "forest") {
      // 아스안 북동 숲: 남서 입구 → 굽은 오솔길 → 북동 공터(세 입구)
      let s = 20260829;
      const rnd = () => (s = s * 16807 % 2147483647) / 2147483647;
      const path = [[2,14],[2,13],[2,12],[3,11],[4,11],[5,10],[6,10],[7,9],[8,9],[9,8],[10,8],[11,7],[12,7],[13,6],[13,5]];
      const inClear = (x, y) => x >= 9 && x <= 17 && y >= 2 && y <= 5;
      const onPath = (x, y) => path.some(([px, py]) => px === x && py === y);
      for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) {
        if (onPath(x, y) || inClear(x, y)) continue;
        if (x <= 3 && y >= 13) continue; // 남서 입구 여유
        if (rnd() < 0.34) tiles[y][x] = 1; // 나무
      }
      path.forEach(([x, y]) => { tiles[y][x] = 6; });
      tiles[15][2] = 6; // 출구 쪽 길 표시
      for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) {
        if (tiles[y][x] === 1) {
          const open = [[1,0],[-1,0],[0,1],[0,-1]].some(([dx, dy]) => [0, 6].includes(tiles[y + dy]?.[x + dx]));
          if (!open) tiles[y][x] = 0;
        }
      }
    } else {
      for (let i = 0; i < 28 + floor * 4; i++) {
        const x = 2 + ((i * 7 + floor * 3) % (cols - 4));
        const y = 2 + ((i * 11 + floor * 5) % (rows - 4));
        if (!(x === 8 && y === 8)) tiles[y][x] = 1;
      }
      for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) {
        if (tiles[y][x] === 1) {
          const open = [[1,0],[-1,0],[0,1],[0,-1]].some(([dx, dy]) => tiles[y + dy]?.[x + dx] === 0);
          if (!open) tiles[y][x] = 0;
        }
      }
    }
    return { cols, rows, tiles, kind };
  }

  function spawnFloor() {
    const p = state.player;
    const area = state.area;
    state.map = makeMap(area === "dungeon" ? "dungeon" : area, state.floor);
    state.npcs = [];
    state.enemies = [];
    state.chests = [];
    state.exits = [];
    if (area === "town") {
      p.x = 7; p.y = 12; state.floor = 0;
      if (p.nights >= 2) {
        if (p.disasters.well !== "done") { p.disasters.well = "fail"; p.heraldGone = true; }
        if (p.disasters.sky !== "done") { p.disasters.sky = "fail"; p.burned = true; }
      }
      state.npcs = [
        { x: 5, y: 5, name: "잔신의 촌장", talk: townTalk },
        { x: 14, y: 5, name: "파편 수집가", talk: collectorTalk },
        { x: 23, y: 5, name: "북동 오솔길 표지", talk: () => openDialog("북동 오솔길 표지", [
          "북동쪽 숲으로 이어진다.",
          "숲 끝에 버려진 성이 있다. 입구는 셋이라고 적혀 있다.",
        ]) },
        { x: 2, y: 10, name: "달력 돌", talk: () => plantTalk("H03", "달력 돌", ["새겨진 계절이 하루를 건너뛰었다.", "누가 달력을 씹는지, 돌은 말하지 않는다."]) },
        { x: 19, y: 3, name: "궤도 광인", talk: madTalk },
        { x: 8, y: 13, name: "먼지의 부랑", talk: () => plantTalk("H05", "먼지의 부랑", ["이 흙은 이 땅이 아니다. 항로에서 떨어졌다.", "별 이름이 있는데, 너희 지도에는 칸이 없다."]) },
        { x: 16, y: 8, name: "등대 유품", talk: () => plantTalk("H06", "등대 유품", ["나선. 팔이 일곱. 등대지기 스케치라 적혀 있다.", "바다는 이 그림에 없다."]) },
        { x: 3, y: 13, name: "실 쥔 아이", talk: () => plantTalk("H07", "실 쥔 아이", ["먼 불빛들을 잇는 실이야.", "끊으면 떨어진대. 어디로는 안 가르쳐 줬어."]) },
        { x: 12, y: 2, name: "낙서 우물", talk: () => plantTalk("H08", "낙서 우물", ["1=1이 아니라고 적혀 있다.", "지워도 밤에 다시 생긴다."]) },
        { x: 20, y: 7, name: "갈래 우물", talk: wellTalk },
        { x: 7, y: 2, name: "축이 빈 비석", talk: () => plantTalk("H10", "축이 빈 비석", ["글이 읽히다가 방향을 바꾼다.", "…", "문장이 비었다."]) },
        { x: 1, y: 7, name: "문 없는 문짝", talk: () => plantTalk("H11", "문 없는 문짝", ["닫혀 있다. 문이 없다.", "이름은 적혀 있지 않다."]) },
      ];
      if (!p.heraldGone) {
        state.npcs.push({ x: 10, y: 11, name: "왕도의 전령", talk: heraldTalk });
      } else {
        state.npcs.push({ x: 10, y: 11, name: "빈 자리", talk: () => openDialog("빈 자리", ["전령의 이름만 지워져 있다. 우물이 삼켰다."]) });
      }
      if (p.disasters.sky === "open" || p.disasters.sky === "done") {
        state.npcs.push({ x: 11, y: 1, name: "내려온 조각", talk: shardTalk });
      }
      if (p.burned) {
        const m = state.map;
        for (let y = 1; y < 4; y++) for (let x = 8; x < 14; x++) if (m.tiles[y][x] === 0) m.tiles[y][x] = 4;
      }
      state.stairs = null;
      state.exits = [{
        x: 26, y: 2, label: "북동 숲",
        run: () => {
          state.area = "forest"; state.floor = 0; spawnFloor();
          state.player.x = 2; state.player.y = 14;
          state.player.visited.add("forest");
          log("아스안 북동 숲에 들어섰다.", true);
        },
      }];
    } else if (area === "forest") {
      p.x = 2; p.y = 14; state.floor = 0;
      // 숲을 지키는 잔재들
      const basics = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === "정석");
      const n = 3 + rand(0, 2);
      for (let i = 0; i < n; i++) {
        const pos = emptyTile();
        const id = basics[rand(0, basics.length - 1)];
        state.enemies.push({ id, x: pos.x, y: pos.y, hp: MONSTERS[id].hp, alive: true, t: Math.random() * 100, seed: Math.random() * 10 });
      }
      // 숲 끝 공터: 기성의 세 입구
      state.npcs = [
        { x: 11, y: 3, name: "재의 왕좌", talk: () => enterDungeon("ember") },
        { x: 13, y: 3, name: "이름 없는 해안", talk: () => enterDungeon("tide") },
        { x: 15, y: 3, name: "뿌리의 속삭임", talk: () => enterDungeon("root") },
        { x: 17, y: 3, name: "기성 표지석", talk: () => openDialog("기성 표지석", [
          "길려진 해의 기성. 해가 길려 나간 성.",
          "입구가 셋이다. 세 입구를 모두 지나면 극의 문이 열린다—고들 한다.",
        ]) },
      ];
      state.stairs = null;
      state.exits = [{
        x: 2, y: 15, label: "아스안 마을",
        run: () => {
          state.area = "town"; state.floor = 0; spawnFloor();
          state.player.x = 25; state.player.y = 3;
          log("마을로 돌아왔다.");
        },
      }];
    } else {
      p.x = 8; p.y = 8;
      const basics = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === "정석");
      const kins = Object.keys(MONSTERS).filter(id => MONSTERS[id].kind === "권속");
      const n = 6 + state.floor;
      for (let i = 0; i < n; i++) {
        const pos = emptyTile();
        const rareKin = Math.random() < 0.08;
        const id = rareKin ? kins[rand(0, kins.length - 1)] : basics[rand(0, basics.length - 1)];
        state.enemies.push({ id, x: pos.x, y: pos.y, hp: MONSTERS[id].hp, alive: true, t: Math.random() * 100, seed: Math.random() * 10 });
      }
      if (state.floor >= 3 && Math.random() < 0.2) {
        const pos = emptyTile();
        const tid = Math.random() < 0.5 ? "titled_echo" : "titled_dust";
        state.enemies.push({ id: tid, x: pos.x, y: pos.y, hp: MONSTERS[tid].hp, alive: true, t: 0, seed: 0 });
      }
      if (state.floor >= 3) {
        const pos = emptyTile();
        state.npcs.push({ x: pos.x, y: pos.y, name: "지워진 해의 자리", talk: () => {
          bumpQuest("start", 1);
          plantHook("H16");
          openDialog("지워진 해의 자리", [
            "해가 길려 나갔다. 성만 남았다.",
            "형상은 여기 없다. 버려진 던전이다. 메인 조사는 여기까지.",
          ]);
        }});
      }
      for (let i = 0; i < 2; i++) {
        const pos = emptyTile();
        state.chests.push({ x: pos.x, y: pos.y, open: false, item: i ? "ether" : "herb", openT: 0 });
      }
      if (state.floor === 2 && state.player.dungeon === "tide" && !state.player.inv.god_thread) {
        const pos = emptyTile();
        state.npcs.push({ x: pos.x, y: pos.y, name: "개연의 제단", talk: () => {
          if (state.player.inv.god_thread) {
            openDialog("개연의 제단", ["이미 파편을 쥐고 있다. 개연은 하나뿐이다."]);
          } else {
            addItem("god_thread");
            openDialog("개연의 제단", ["신의 개연 파편. 마을급에는 이것 하나다."]);
          }
        }});
      }
      state.stairs = emptyTile();
    }
    buildLayer();
  }

  function emptyTile() {
    const m = state.map;
    for (let k = 0; k < 80; k++) {
      const x = 2 + Math.floor(Math.random() * (m.cols - 4));
      const y = 2 + Math.floor(Math.random() * (m.rows - 4));
      const onExit = state.exits.some(e => e.x === x && e.y === y);
      if (m.tiles[y][x] === 0 && !(x === 8 && y === 8) && !onExit && !occupied(x, y)) return { x, y };
    }
    return { x: 10, y: 10 };
  }
  function occupied(x, y) {
    return state.enemies.some(e => e.alive && e.x === x && e.y === y) ||
      state.chests.some(c => c.x === x && c.y === y) ||
      state.npcs.some(n => n.x === x && n.y === y);
  }

  function plantHook(id) {
    const p = state.player;
    if (!p || p.hooks.has(id)) return;
    p.hooks.add(id);
    log("흔적: " + HOOKS[id].title, true);
    bumpQuest("hooks", p.hooks.size);
  }
  function plantTalk(id, who, lines) {
    plantHook(id);
    if (id === "H10") plantHook("H15");
    openDialog(who, lines);
  }
  /* ── 퀘스트 수주: 잔신의 촌장이 의뢰자 ──
   * 수주(lock 해제) 전에는 HUD/퀘스트 탭에 보이지 않는다. */
  function shardCount() {
    const p = state.player;
    return ["ember_shard", "tide_pearl", "root_seed"].reduce((s, k) => s + (p.inv[k] || 0), 0);
  }
  function acceptQuest(id) {
    const p = state.player;
    const q = p.quests.find(x => x.id === id);
    if (!q || !q.locked) return false;
    q.locked = false;
    // 수주 시점까지 쌓인 진행도 반영
    if (id === "collect") q.cur = Math.min(q.need, shardCount());
    if (id === "hooks") q.cur = Math.min(q.need, p.hooks.size);
    if (id === "well" && p.disasters.well === "done") q.cur = q.need;
    if (id === "sky" && p.disasters.sky === "done") q.cur = q.need;
    if (id === "start" && p.hooks.has("H16")) q.cur = 1;
    if (q.cur >= q.need) { q.done = true; p.gold += 20; log("퀘스트 완료: " + q.title, true); }
    else log("퀘스트 수주: " + q.title, true);
    hud(); renderPanel();
    return true;
  }
  function nextChiefOffer() {
    const p = state.player;
    const q = id => p.quests.find(x => x.id === id);
    // 재앙이 열려 있으면 최우선
    if ((p.disasters.well === "open" || p.disasters.well === "fail") && q("well").locked) return "well";
    if ((p.disasters.sky === "open" || p.disasters.sky === "fail") && q("sky").locked) return "sky";
    for (const id of ["start", "scar", "hunt", "collect", "hooks"]) if (q(id).locked) return id;
    return null;
  }
  const CHIEF_OFFER = {
    start:  ["…그럼, 시작하지.", "북동쪽 숲을 지나면 버려진 성이 있다. 「길려진 해의 기성」. 3층을 조사해라.", "형상은 없을 거다. 그래도 가야 한다."],
    scar:   ["접힌 자국에 시달리는 자들이 있다.", "제단 약초를 한 움큼 가져오라.", "…아무 일도 없겠지만, 해야 한다."],
    hunt:   ["던전의 잔재가 밤마다 마을로 새고 있다.", "놈들을 정리해라. 잔액 여덟이면 형세가 눅는다.", "숲에도 남아 있다. 조심해라."],
    collect:["수집가가 입구 파편을 찾더군.", "파편 세 개를 모아 와라. 일곱이 아니라, 셋이다.", "나머지 이야기는 수집가에게 들어라."],
    hooks:  ["마을에 심어진 말들이 있다. 너도 들었을 거다.", "흔적 여덟을 기록해라.", "지금은 풀지 않는다. 나중을 위해서다."],
    well:   ["우물이 사람을 삼키고 있다!", "파편 하나를 제물 대신 던져라. 갈래 우물로 가라.", "전령이… 아니, 얘기는 나중에 하마."],
    sky:    ["하늘 구멍이 낮아진다! 북쪽에 조각이 떨어졌다!", "신유(神油)로 식혀라. 땅이 타기 전에.", "광인의 말이 맞았군. 일이 이렇게 될 줄이야."],
  };
  function townTalk() {
    const p = state.player;
    plantHook("H01");
    plantHook("H12");
    // 약초 진료는 「접힌 자국의 약」 수주 후에만
    const scar = p.quests.find(q => q.id === "scar");
    if (!scar.locked && !scar.done && (p.inv.herb || 0) > 0) {
      p.inv.herb--;
      bumpQuest("scar", 1);
      openDialog("잔신의 촌장", [
        "약초를 바쳤군. …아무 일도 없다.",
        "지금은 안 듣는다. 접힌 자국은 나중에야 약이 된다.",
      ]);
      return;
    }
    const offer = nextChiefOffer();
    if (offer) {
      acceptQuest(offer);
      openDialog("잔신의 촌장", CHIEF_OFFER[offer]);
      return;
    }
    openDialog("잔신의 촌장", [
      "의뢰는 더 없다.",
      "북동쪽 숲에 버려진 던전. 왕도 전령, 우물, 하늘 구멍은 재앙이다.",
      "메인은 기성이다.",
    ]);
  }
  function heraldTalk() {
    plantTalk("H02", "왕도의 전령", [
      "편지를 열면 법령이 손을 탄다.",
      "우물이 밤마다 이름을 삼킨다. 나는 아직 있다. 아직은.",
    ]);
  }
  function madTalk() {
    plantHook("H04");
    const p = state.player;
    if (p.disasters.sky === "idle") {
      p.disasters.sky = "open";
      log("특별 재앙: 하늘 구멍이 낮아진다.", true);
    }
    const skyLines = [
      "구멍이 낮아진다. 북쪽에 조각이 떨어졌다.",
      "신유로 식히지 않으면 땅이 탄다. 행성 이야기가 아니다. 아직은.",
    ];
    if (p.quests.find(q => q.id === "sky").locked) skyLines.push("…마을 촌장에게 보고하면 의뢰가 될 거다.");
    openDialog("궤도 광인", skyLines);
    if (state.floor === 0 && !state.npcs.some(n => n.name === "내려온 조각")) {
      state.npcs.push({ x: 11, y: 1, name: "내려온 조각", talk: shardTalk });
    }
  }
  function shardTalk() {
    const p = state.player;
    if (p.disasters.sky === "done") {
      openDialog("내려온 조각", ["식었다. 구멍은 다시 멀다. 완전히는 아니다."]);
      return;
    }
    if ((p.inv.ether || 0) > 0) {
      p.inv.ether--;
      p.disasters.sky = "done";
      bumpQuest("sky", 1);
      openDialog("내려온 조각", ["신유가 열을 접었다. 하늘 구멍은 조금 멀어졌다.", "궤도 제단은 아직 있다. 회수는 행성급."]);
    } else {
      p.hp = Math.max(1, Math.floor(p.hp * 0.5));
      hud();
      openDialog("내려온 조각", ["맨손으로 만졌다. 몸이 반으로 익었다.", "신유(神油)가 필요하다."]);
    }
  }
  function wellTalk() {
    plantHook("H09");
    const p = state.player;
    if (p.disasters.well === "idle") {
      p.disasters.well = "open";
      log("특별 재앙: 우물이 사람을 삼킨다.", true);
    }
    if (p.disasters.well === "done") {
      openDialog("갈래 우물", ["금이 갔다. 지워짐은 멈췄다. 다른 나는 아직 물결에 있다."]);
      return;
    }
    const keys = ["ember_shard", "tide_pearl", "root_seed"];
    const have = keys.find(k => p.inv[k] > 0);
    if (have) {
      p.inv[have]--;
      p.disasters.well = "done";
      bumpQuest("well", 1);
      openDialog("갈래 우물", [
        ITEMS[have].name + "을 제물 대신 던졌다.",
        "우물이 사람을 그만 삼킨다. 금이 간다. 회수는 다중우주.",
      ]);
    } else {
      const lines = [
        "메아리가 먼저 대답한다. 아직 묻지 않은 말로.",
        "밤마다 이름이 하나 지워진다. 파편을 제물 대신 던져라.",
      ];
      if (p.quests.find(q => q.id === "well").locked) lines.push("…촌장에게 보고하면 의뢰가 될 거다.");
      openDialog("갈래 우물", lines);
    }
  }
  function collectorTalk() {
    const p = state.player;
    const keys = ["ember_shard", "tide_pearl", "root_seed"];
    const n = keys.reduce((s, k) => s + (p.inv[k] || 0), 0);
    bumpQuest("collect", n);
    plantHook("H13");
    plantHook("H14");
    openDialog("파편 수집가", [
      "악성은 죽여도 국경 너머에서 다시 핀다. 여긴 형상일 뿐이야.",
      "파편 " + n + "조각. 일곱이면 극의 문이 열린다—고들 하지.",
      "나는 그게 너무 쉽다고 생각하네. 지금은 모으기만 하게.",
    ]);
  }
  function enterDungeon(id) {
    startTravel(() => {
      state.player.nights++;
      state.player.dungeon = id;
      state.player.visited.add("haesung");
      state.story = STORIES[0];
      state.area = "dungeon";
      state.floor = 1;
      spawnFloor();
      log("버려진 던전 「길려진 해의 기성」 1층.", true);
    });
  }

  function openDialog(who, lines) {
    state.dialog = { who, lines, i: 0 };
    state.screen = "dialog";
  }

  function bumpQuest(id, cur) {
    const q = state.player.quests.find(q => q.id === id);
    if (!q || q.done || q.locked) return;
    q.cur = Math.min(q.need, typeof cur === "number" ? cur : q.cur + 1);
    if (q.cur >= q.need) { q.done = true; log("퀘스트 완료: " + q.title, true); state.player.gold += 20; }
    renderPanel();
  }

  function useItem(id) {
    const p = state.player;
    if (!p.inv[id]) return;
    const it = ITEMS[id];
    if (it.type === "heal") {
      p.hp = Math.min(p.maxHp, p.hp + it.val);
      p.inv[id]--;
      log(it.name + "을(를) 사용했다.");
    } else if (it.type === "mana") {
      p.mp = Math.min(p.maxMp, p.mp + it.val);
      p.inv[id]--;
      log(it.name + "을(를) 사용했다.");
    } else {
      log(it.name + "은(는) 사용할 수 없다.");
    }
    hud(); renderPanel();
  }

  function addItem(id, n = 1) {
    state.player.inv[id] = (state.player.inv[id] || 0) + n;
    log(ITEMS[id].name + " 획득 ×" + n, true);
    if (["ember_shard", "tide_pearl", "root_seed"].includes(id)) {
      const keys = ["ember_shard", "tide_pearl", "root_seed"];
      const c = keys.reduce((s, k) => s + (state.player.inv[k] || 0), 0);
      bumpQuest("collect", c);
    }
    if (itRelic(id)) {
      state.player.relic = id;
      bumpQuest("start", 1);
      state.screen = "win";
    }
    renderPanel();
  }
  function itRelic(id) { return ITEMS[id]?.type === "relic"; }

  function startBattle(en) {
    const m = MONSTERS[en.id];
    state.player.codex.add(en.id);
    state.battle = {
      en, m,
      ehp: en.hp,
      log: m.name + " 나타났다!",
      turn: "player",
      anim: 0, eAnim: 0, eHit: 0, pAtkT: -1, pSkillT: -1,
      hoverBtn: -1,
    };
    state.screen = "battle";
    shake(6);
    renderPanel();
  }

  function battleAct(kind) {
    const b = state.battle, p = state.player;
    if (!b || b.turn !== "player") return;
    let dmg = 0, cost = 0, txt = "";
    if (kind === "atk") { dmg = p.atk + (p.inv.rusty_sword ? 2 : 0) + rand(0, 2); txt = "검을 휘둘렀다!"; b.pAtkT = 0; }
    if (kind === "skill") {
      cost = 4;
      if (p.mp < cost) { b.log = "마나가 부족하다."; return; }
      p.mp -= cost;
      dmg = p.atk * 2 + rand(1, 4);
      txt = "속성 스킬!";
      b.pAtkT = 0; b.pSkillT = 0;
    }
    if (kind === "item") { useItem("herb"); b.log = "약초를 사용했다."; b.turn = "enemy"; hud(); return; }
    if (kind === "run") {
      if (!b.m.boss && Math.random() < 0.55) { state.screen = "play"; log("도망쳤다."); puffDust(W * 0.32, H * 0.62, 3); return; }
      b.log = "도망치지 못했다!"; b.turn = "enemy"; return;
    }
    b.ehp -= dmg;
    b.en.hp = b.ehp;
    b.log = txt + " " + dmg + " 피해.";
    b.anim = 8;
    b.eHit = 0.5;
    dmgNum(W * 0.66, H * 0.34, dmg, kind === "skill");
    puffDust(W * 0.62, H * 0.5, 2);
    shake(kind === "skill" ? 8 : 5);
    if (b.ehp <= 0) { winBattle(); return; }
    b.turn = "enemy";
    hud();
  }

  function winBattle() {
    const b = state.battle, p = state.player, m = b.m;
    b.en.alive = false;
    p.xp += m.xp;
    p.gold += 4 + Math.floor(m.xp / 3);
    if (m.drop && Math.random() < (m.boss ? 1 : 0.55)) addItem(m.drop);
    bumpQuest("hunt");
    log(m.name + " 처치. +" + m.xp + " XP", true);
    while (p.xp >= p.need) {
      p.xp -= p.need; p.lv++; p.need = Math.floor(p.need * 1.35);
      p.maxHp += 6; p.maxMp += 3; p.atk += 2; p.hp = p.maxHp; p.mp = p.maxMp;
      log("레벨 업! Lv." + p.lv, true);
    }
    state.screen = itRelic(m.drop) && p.relic ? "win" : "play";
    state.battle = null;
    hud(); renderPanel();
  }

  function enemyTurn() {
    const b = state.battle, p = state.player;
    if (!b || b.turn !== "enemy") return;
    const dmg = Math.max(1, b.m.atk - p.def + rand(0, 2));
    p.hp -= dmg;
    b.log = b.m.name + "의 공격! " + dmg + " 피해.";
    b.turn = "player";
    b.eAnim = 0.5;
    dmgNum(W * 0.32, H * 0.5, dmg, false);
    shake(7);
    if (p.hp <= 0) {
      p.hp = 0;
      log("쓰러졌다… 마을에서 눈을 뜬다.", true);
      state.area = "town";
      state.floor = 0;
      p.hp = Math.max(1, Math.floor(p.maxHp * 0.5));
      spawnFloor();
      state.screen = "play";
      state.battle = null;
    }
    hud();
  }

  function rand(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }

  function tryInteract() {
    const p = state.player;
    const nx = Math.round(p.x), ny = Math.round(p.y);
    const npc = state.npcs.find(n => Math.abs(n.x - nx) + Math.abs(n.y - ny) <= 1);
    if (npc) { npc.talk(); return; }
    const ch = state.chests.find(c => !c.open && Math.abs(c.x - nx) + Math.abs(c.y - ny) <= 1);
    if (ch) { ch.open = true; ch.openT = 0.0001; addItem(ch.item); puffDust(ch.x * TILE, ch.y * TILE, 2); return; }
    if (state.stairs && Math.abs(state.stairs.x - nx) + Math.abs(state.stairs.y - ny) <= 1) {
      if (state.floor < 3) startTravel(() => { state.floor++; spawnFloor(); log("다음 층으로 내려갔다.", true); });
      else startTravel(() => {
        state.area = "forest"; state.floor = 0; spawnFloor();
        state.player.x = 13; state.player.y = 5;
        log("숲 공터로 돌아왔다.");
      });
    }
  }

  function blocked(x, y) {
    const m = state.map;
    const tx = Math.floor(x + 0.4), ty = Math.floor(y + 0.4);
    if (tx < 0 || ty < 0 || tx >= m.cols || ty >= m.rows) return true;
    const t = m.tiles[ty][tx];
    return t === 1 || t === 2 || t === 3;
  }

  window.addEventListener("keydown", e => {
    keys[e.key.toLowerCase()] = true;
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
    if (state.screen === "title" && (e.key === "Enter" || e.key === " ")) pickStory(Math.max(0, state.hover));
    if (state.screen === "dialog" && (e.key === " " || e.key === "Enter" || e.key === "e")) {
      state.dialog.i++;
      if (state.dialog.i >= state.dialog.lines.length) { state.screen = "play"; state.dialog = null; }
    }
    if (state.screen === "play") {
      if (e.key === " " || e.key.toLowerCase() === "e") tryInteract();
      if (e.key.toLowerCase() === "i") { renderPanel(); document.getElementById("win-modal").classList.remove("hidden"); fillModal("inv"); }
      if (e.key.toLowerCase() === "q") { renderPanel(); document.getElementById("win-modal").classList.remove("hidden"); fillModal("quest"); }
      if (e.key.toLowerCase() === "m") { renderPanel(); document.getElementById("win-modal").classList.remove("hidden"); fillModal("region"); }
    }
    if (state.screen === "battle") {
      if (e.key === "1" || e.key === " ") battleAct("atk");
      if (e.key === "2") battleAct("skill");
      if (e.key === "3") battleAct("item");
      if (e.key === "4" || e.key === "Escape") battleAct("run");
    }
    if (state.screen === "win" && (e.key === "Enter" || e.key === " ")) {
      state.screen = "title"; state.player = null; hud();
    }
  });
  window.addEventListener("keyup", e => { keys[e.key.toLowerCase()] = false; });

  canvas.addEventListener("mousemove", e => {
    const r = canvas.getBoundingClientRect();
    state.mouse.x = (e.clientX - r.left) * (W / r.width);
    state.mouse.y = (e.clientY - r.top) * (H / r.height);
    if (state.screen === "title") {
      state.hover = -1;
      STORIES.forEach((_, i) => {
        const bx = 80, by = 180 + i * 100, bw = 800, bh = 84;
        if (state.mouse.x >= bx && state.mouse.x <= bx + bw && state.mouse.y >= by && state.mouse.y <= by + bh) state.hover = i;
      });
    }
  });
  canvas.addEventListener("click", e => {
    if (state.screen === "title" && state.hover >= 0) pickStory(state.hover);
    if (state.screen === "battle") {
      const acts = ["atk", "skill", "item", "run"];
      acts.forEach((a, i) => {
        const bx = 80 + i * 200, by = 450;
        if (state.mouse.x >= bx && state.mouse.x <= bx + 180 && state.mouse.y >= by && state.mouse.y <= by + 50) battleAct(a);
      });
    }
  });

  function pickStory(i) {
    state.story = STORIES[i] || STORIES[0];
    state.player = newPlayer(state.story);
    state.area = "town";
    state.floor = 0;
    state.pendingTravel = null;
    spawnFloor();
    state.screen = "play";
    log("스토리 「" + state.story.title + "」를 선택했다.", true);
    log(state.story.blurb);
    hud(); renderPanel();
  }

  function update(dt) {
    // 페이드 이동 중에는 세계를 멈춘다
    if (state.pendingTravel) {
      state.pendingTravel.t += dt;
      if (!state.pendingTravel.done && state.pendingTravel.t >= 0.35) {
        state.pendingTravel.done = true;
        state.pendingTravel.run();
      }
      if (state.pendingTravel.t >= 0.7) state.pendingTravel = null;
      return;
    }
    state.time += dt;
    // fx 갱신
    state.fx.dusts = state.fx.dusts.filter(d => (d.t += dt) < 0.45);
    state.fx.dmgs = state.fx.dmgs.filter(d => (d.t += dt) < 0.9);
    state.fx.toasts = state.fx.toasts.filter(t => (t.t += dt) < 2.6);
    if (state.fx.shake > 0) state.fx.shake = Math.max(0, state.fx.shake - dt * 26);
    state.chests.forEach(c => { if (c.open && c.openT < 0.4) c.openT += dt; });
    if (state.screen !== "play") { if (state.screen === "battle") battleTick(dt); return; }
    const p = state.player;
    let dx = 0, dy = 0;
    if (keys["w"] || keys["arrowup"]) dy -= 1;
    if (keys["s"] || keys["arrowdown"]) dy += 1;
    if (keys["a"] || keys["arrowleft"]) dx -= 1;
    if (keys["d"] || keys["arrowright"]) dx += 1;
    const sp = 4.2 * dt;
    p.moving = !!(dx || dy);
    if (dx || dy) {
      if (dy > 0) p.facing = 0; else if (dy < 0) p.facing = 3;
      if (dx > 0) p.facing = 1; else if (dx < 0) p.facing = 2;
      const len = Math.hypot(dx, dy);
      dx /= len; dy /= len;
      const ox = p.x, oy = p.y;
      if (!blocked(p.x + dx * sp, p.y)) p.x += dx * sp;
      if (!blocked(p.x, p.y + dy * sp)) p.y += dy * sp;
      p.animT += dt;
      if (Math.random() < dt * 3) puffDust(W / 2 - 2, H / 2 + 14, 1);
    } else {
      p.animT = 0;
    }
    // 출구 타일을 밟으면 이동
    const exHit = state.exits.find(e => e.x === Math.round(p.x) && e.y === Math.round(p.y));
    if (exHit) { startTravel(exHit.run); return; }
    state.enemies.forEach(en => {
      if (!en.alive) return;
      en.t += dt;
      if (en.t > 1.2) {
        en.t = 0;
        const step = [[1, 0], [-1, 0], [0, 1], [0, -1]][rand(0, 3)];
        const nx = en.x + step[0], ny = en.y + step[1];
        if (!blocked(nx, ny) && !occupied(nx, ny)) { en.x = nx; en.y = ny; }
      }
      if (Math.abs(en.x - p.x) < 0.7 && Math.abs(en.y - p.y) < 0.7) startBattle(en);
    });
    hud();
  }

  function battleTick(dt) {
    const b = state.battle;
    if (!b) return;
    if (b.eHit > 0) b.eHit -= dt;
    if (b.eAnim > 0) b.eAnim -= dt;
    if (b.pAtkT >= 0) { b.pAtkT += dt; if (b.pAtkT > 0.5) b.pAtkT = -1; }
    if (b.pSkillT >= 0) { b.pSkillT += dt; if (b.pSkillT > 0.6) b.pSkillT = -1; }
    if (b.anim > 0) b.anim -= dt * 12;
  }

  /* ============================================================
   * 렌더링 — Mystic Woods 스프라이트
   * ============================================================ */
  const FACENAME = ["down", "left", "right", "up"];

  function pal() {
    const s = state.story?.id;
    if (s === "haesung") return { floor: "#1c2228", wall: "#0c1014", accent: "#8a9aa8", grass: "#3a4a30" };
    return { floor: "#1c2228", wall: "#0c1014", accent: "#8a9aa8", grass: "#3a4a30" };
  }

  function tileImg(t, x, y) {
    const F = Assets.F;
    const m = state.map;
    const n = (x * 13 + y * 7);
    if (m.kind === "dungeon") {
      if (t === 0) return (n % 11 === 0) ? F.tiles.carpet[0] : F.tiles.wood[0];
      return null; // 석벽
    }
    // 야외(마을/숲)
    if (t === 0 || t === 4 || t === 7) return F.tiles.grass[n % F.tiles.grass.length];
    if (t === 5) return F.tiles.grass[(n + 1) % F.tiles.grass.length];
    if (t === 6 || t === 8) return F.tiles.dirt[n % F.tiles.dirt.length];
    return null;
  }

  /* 정적 레이어: 타일 + 그림자 + 프롭 (물/불타는 땅 제외) */
  function buildLayer() {
    if (!Assets.ready.ok) { state.layer = null; return; }
    const F = Assets.F;
    const m = state.map;
    state.layerOX = 96; state.layerOY = 128;
    const [c, x] = (() => {
      const cc = document.createElement("canvas");
      cc.width = m.cols * TILE + state.layerOX * 2;
      cc.height = m.rows * TILE + state.layerOY * 2;
      const xx = cc.getContext("2d");
      xx.imageSmoothingEnabled = false;
      return [cc, xx];
    })();
    for (let ty = 0; ty < m.rows; ty++) {
      for (let tx = 0; tx < m.cols; tx++) {
        const t = m.tiles[ty][tx];
        const px = state.layerOX + tx * TILE, py = state.layerOY + ty * TILE;
        // 바닥
        if (t === 3) { // 물 바닥은 프레임마다 그리지만 바탕으로 어두운 물
          x.fillStyle = "#20303f";
          x.fillRect(px, py, TILE, TILE);
        } else if (t === 1 && m.kind === "dungeon") {
          x.drawImage(F.tiles.wood[0], 0, 0, 16, 16, px, py, TILE, TILE);
        } else if (t === 1) {
          x.drawImage(F.tiles.grass[(tx * 13 + ty * 7) % F.tiles.grass.length], 0, 0, 16, 16, px, py, TILE, TILE);
        } else {
          const img = tileImg(t, tx, ty);
          if (img) x.drawImage(img, 0, 0, 16, 16, px, py, TILE, TILE);
        }
        // 던전 석벽
        if (t === 1 && m.kind === "dungeon") {
          const belowWall = ty + 1 < m.rows && m.tiles[ty + 1][tx] === 1;
          const face = (tx * 7 + ty * 3) % 5 === 0 ? F.tiles.wallFace2 : F.tiles.wallFace;
          const top = (tx * 5 + ty * 11) % 7 === 0 ? F.tiles.wallTop2 : F.tiles.wallTop;
          // 아래 칸이 벽이면 "윗면", 아니면 앞면(밝은 표면)
          x.drawImage(top, 0, 0, 16, 16, px, py, TILE, TILE);
          if (!belowWall) x.drawImage(face, 0, 0, 16, 16, px, py, TILE, TILE);
          // 벽 상단 그림자
          x.fillStyle = "rgba(0,0,0,.28)";
          x.fillRect(px, py, TILE, TILE * 0.22);
        }
        // 경계/숲 나무 = 나무 군락
        if (t === 1 && m.kind !== "dungeon" && F.props.treeClump) {
          const seed = (tx * 31 + ty * 17) % 4;
          x.drawImage(F.props.treeClump, seed * 16, 0, 16, 16, px, py + 8, TILE, 24);
          x.drawImage(F.props.treeClump, seed * 16, 24, 16, 24, px, py - 16, TILE, 36);
        }
        // 숲 바닥 소품: 수풀/바위
        if (t === 0 && m.kind === "forest" && (tx * 17 + ty * 29) % 13 === 0 && F.props.bush && !state.exits.some(e => e.x === tx && e.y === ty)) {
          x.drawImage(F.props.bush, 0, 0, F.props.bush.width, F.props.bush.height, px + 2, py + 4, 28, 20);
        }
        if (t === 0 && m.kind === "forest" && (tx * 23 + ty * 11) % 29 === 0 && F.props.rock) {
          x.drawImage(F.props.rock, 0, 0, F.props.rock.width, F.props.rock.height, px - 4, py - 2, 40, 30);
        }
        // 마을 숲 지대(t=5): 나무 데칼
        if (t === 5 && m.kind === "town" && F.props.treeClump) {
          const seed = (tx * 13 + ty * 7) % 4;
          if (seed < 2) {
            x.drawImage(F.props.treeClump, seed * 24, 0, 24, 24, px - 4, py - 20, 40, 40);
          } else if (F.props.bush) {
            x.drawImage(F.props.bush, 0, 0, F.props.bush.width, F.props.bush.height, px + 2, py + 2, 28, 20);
          }
        }
        // 집(t=2): 목조 벽 + 지붕 테두리
        if (t === 2) {
          x.drawImage(F.tiles.wallTop, 0, 0, 16, 16, px, py, TILE, TILE);
          x.fillStyle = "#3a2a1a";
          x.fillRect(px, py + TILE - 6, TILE, 6);
          x.fillStyle = "#57402a";
          x.fillRect(px, py + TILE - 6, TILE, 2);
        }
        // 바위(t=7)
        if (t === 7 && F.props.rock) {
          x.drawImage(F.props.rock, 0, 0, F.props.rock.width, F.props.rock.height, px - 6, py - 6, 44, 33);
        }
        // 던전 바닥 장식: 수정
        if (t === 0 && m.kind === "dungeon" && F.props.crystal && (tx * 29 + ty * 47) % 23 === 0) {
          x.globalAlpha = 0.9;
          x.drawImage(F.props.crystal, 0, 0, F.props.crystal.width, F.props.crystal.height, px, py - 10, 34, 36);
          x.globalAlpha = 1;
        }
        // 물 가장자리 음영
        if (t === 3) {
          const up = ty > 0 && m.tiles[ty - 1][tx] !== 3;
          if (up) { x.fillStyle = "rgba(0,0,0,.35)"; x.fillRect(px, py, TILE, 5); }
        }
        // 그리드 조짐(미세 명도차)
        if ((tx + ty) % 2 === 0 && t !== 3 && t !== 1) {
          x.fillStyle = "rgba(255,255,255,.025)";
          x.fillRect(px, py, TILE, TILE);
        }
      }
    }
    // 숲 분위기: 서늘한 어둡기
    if (m.kind === "forest") {
      x.fillStyle = "rgba(8,24,14,.18)";
      x.fillRect(0, 0, c.width, c.height);
    }
    // 출구 표지판
    state.exits.forEach(ex => {
      const px = state.layerOX + ex.x * TILE, py = state.layerOY + ex.y * TILE;
      x.drawImage(F.tiles.dirt[0], 0, 0, 16, 16, px, py, TILE, TILE);
      x.fillStyle = "#6b4a2b"; x.fillRect(px + 14, py + 6, 4, 22);
      x.fillStyle = "#8a6136"; x.fillRect(px + 3, py + 2, 26, 14);
      x.strokeStyle = "#3a2a1a"; x.lineWidth = 2; x.strokeRect(px + 3, py + 2, 26, 14);
      x.fillStyle = "#3a2a1a";
      x.fillRect(px + 7, py + 6, 16, 2);
      x.fillRect(px + 7, py + 10, 10, 2);
    });
    state.layer = c;
  }

  function drawWorld() {
    const m = state.map, p = state.player, c = pal();
    const ox = Math.floor(W / 2 - p.x * TILE - TILE / 2);
    const oy = Math.floor(H / 2 - p.y * TILE - TILE / 2);
    const sh = state.fx.shake;
    const sox = sh ? Math.round(Math.sin(state.time * 90) * sh) : 0;
    const soy = sh ? Math.round(Math.cos(state.time * 70) * sh * 0.6) : 0;
    ctx.save();
    ctx.translate(sox, soy);

    // 바탕(맵 밖)
    const F = Assets.F;
    if (m.kind === "town") {
      ctx.fillStyle = "#2c4a26";
      ctx.fillRect(-40, -40, W + 80, H + 80);
    } else if (m.kind === "forest") {
      ctx.fillStyle = "#1d3a20";
      ctx.fillRect(-40, -40, W + 80, H + 80);
    } else {
      ctx.fillStyle = "#14100e";
      ctx.fillRect(-40, -40, W + 80, H + 80);
    }

    if (state.layer && GFX.on) {
      ctx.drawImage(state.layer, ox - state.layerOX, oy - state.layerOY);
    } else {
      // 폴백: 단색 타일
      for (let y = 0; y < m.rows; y++) for (let x = 0; x < m.cols; x++) {
        const t = m.tiles[y][x];
        const px = ox + x * TILE, py = oy + y * TILE;
        ctx.fillStyle = tileColor(t, x, y, m.kind === "town" ? "#45883a" : c.floor);
        ctx.fillRect(px, py, TILE, TILE);
      }
    }

    /* --- 물 애니메이션 --- */
    if (GFX.on && F.waterOk) {
      const wf = F.water[Math.floor(state.time * 5) % 6];
      const wf2 = F.waterAlt[Math.floor(state.time * 5) % 6];
      for (let y = 0; y < m.rows; y++) for (let x = 0; x < m.cols; x++) {
        if (m.tiles[y][x] !== 3) continue;
        const px = ox + x * TILE, py = oy + y * TILE;
        ctx.drawImage((x + y) % 3 === 0 ? wf2 : wf, 0, 0, 16, 16, px, py, TILE, TILE);
        // 물빛 틴트 + 물결 하이라이트
        ctx.fillStyle = "rgba(38,86,128,.22)";
        ctx.fillRect(px, py, TILE, TILE);
        const ph = Math.sin(state.time * 2.2 + x * 1.3 + y * 0.9);
        if (ph > 0.55) {
          ctx.fillStyle = `rgba(190,225,255,${(ph - 0.55) * 0.5})`;
          ctx.fillRect(px + 6, py + 10 + ph * 4, 10, 2);
          ctx.fillRect(px + 18, py + 20 - ph * 3, 6, 2);
        }
      }
    }

    /* --- 불탄 땅(t=4) 잔불 --- */
    if (p.burned) {
      for (let y = 1; y < 4; y++) for (let x = 8; x < 14; x++) {
        if (m.tiles[y]?.[x] !== 4) continue;
        const px = ox + x * TILE, py = oy + y * TILE;
        const g = 0.35 + 0.3 * Math.sin(state.time * 6 + x * 3 + y);
        ctx.fillStyle = `rgba(224,112,48,${0.10 + g * 0.1})`;
        ctx.fillRect(px + 6, py + 8, 20, 14);
        ctx.fillStyle = `rgba(255,200,90,${g * 0.5})`;
        ctx.fillRect(px + 13, py + 13, 3, 3);
        ctx.fillRect(px + 20, py + 18, 2, 2);
      }
    }

    /* --- 계단 --- */
    if (state.stairs) {
      const px = ox + state.stairs.x * TILE, py = oy + state.stairs.y * TILE;
      if (GFX.on) {
        ctx.fillStyle = "#0a0806";
        ctx.beginPath(); ctx.ellipse(px + 16, py + 18, 15, 11, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#241a10"; ctx.fillRect(px + 6, py + 12, 20, 4);
        ctx.fillStyle = "#3a2c1c"; ctx.fillRect(px + 8, py + 8, 16, 4);
        ctx.fillStyle = "#57402a"; ctx.fillRect(px + 10, py + 4, 12, 4);
        const g = 0.5 + 0.4 * Math.sin(state.time * 4);
        ctx.fillStyle = `rgba(230,193,90,${g * 0.7})`;
        ctx.font = "bold 10px sans-serif"; ctx.textAlign = "center";
        ctx.fillText("▼", px + 16, py + 30 - g * 3);
        ctx.textAlign = "left";
      } else {
        ctx.fillStyle = "#c9a227";
        ctx.fillRect(px + 6, py + 6, 20, 20);
      }
    }

    /* --- 출구 마커 --- */
    state.exits.forEach(ex => {
      const px = ox + ex.x * TILE + 16, py = oy + ex.y * TILE - 6 + Math.sin(state.time * 3) * 2.5;
      ctx.font = "bold 11px sans-serif";
      const tw = ctx.measureText(ex.label).width;
      ctx.fillStyle = "rgba(10,8,6,.72)";
      ctx.beginPath(); ctx.roundRect(px - tw / 2 - 6, py - 22, tw + 28, 18, 4); ctx.fill();
      ctx.strokeStyle = "rgba(230,193,90,.5)"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(px - tw / 2 - 6, py - 22, tw + 28, 18, 4); ctx.stroke();
      ctx.fillStyle = "#e6c15a"; ctx.textAlign = "center";
      ctx.fillText("▶ " + ex.label, px, py - 9);
      ctx.textAlign = "left";
    });

    /* --- 상자 --- */
    state.chests.forEach(ch => {
      const px = ox + ch.x * TILE, py = oy + ch.y * TILE;
      if (GFX.on && F.chest) {
        const t = ch.open ? Math.min(3, Math.floor((ch.openT || 0) * 10)) : 0;
        ctx.drawImage(F.chest[t], 0, 0, 16, 16, px + 2, py + 4, 28, 28);
        if (!ch.open) {
          const g = 0.3 + 0.25 * Math.sin(state.time * 3);
          ctx.fillStyle = `rgba(230,193,90,${g})`;
          ctx.fillRect(px + 13, py - 2, 6, 3);
        }
      } else {
        ctx.fillStyle = ch.open ? "#5a4030" : "#d4a017";
        ctx.fillRect(px + 8, py + 10, 16, 14);
      }
    });

    /* --- 엔티티 정렬(y 기준) --- */
    const ents = [];
    state.npcs.forEach(n => ents.push({ type: "npc", o: n, y: n.y }));
    state.enemies.forEach(en => { if (en.alive) ents.push({ type: "en", o: en, y: en.y }); });
    ents.push({ type: "player", o: p, y: p.y + 0.01 });
    ents.sort((a, b) => a.y - b.y);

    ents.forEach(e => {
      if (e.type === "player") drawPlayerWorld(ox, oy, p);
      else if (e.type === "en") drawEnemyWorld(ox, oy, e.o);
      else drawNPC(ox, oy, e.o);
    });

    ctx.restore();

    /* --- 상호작용 힌트 (E) --- */
    drawInteractHint(ox, oy);

    /* --- 파티클 --- */
    drawFX();

    /* --- 환경 빛 --- */
    drawAmbient(m);

    drawMini(m, p);
  }

  function drawShadow(cx, cy, w) {
    ctx.fillStyle = "rgba(0,0,0,.30)";
    ctx.beginPath();
    ctx.ellipse(cx, cy, w, w * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  function playerFrame(p) {
    const F = Assets.F;
    const dir = FACENAME[p.facing] || "down";
    if (p.moving) {
      const fr = F.player.walk[dir];
      return fr[Math.floor(p.animT * 9) % fr.length];
    }
    const fr = F.player.idle[dir];
    return fr[Math.floor(state.time * 1.6) % 2 === 0 ? 0 : 3];
  }

  function drawPlayerWorld(ox, oy, p) {
    const px = ox + p.x * TILE, py = oy + p.y * TILE;
    if (!GFX.on) {
      ctx.fillStyle = "#2a4068";
      ctx.fillRect(px + 10, py + 16, 12, 12);
      ctx.fillStyle = "#f0d0a8";
      ctx.fillRect(px + 11, py + 8, 10, 10);
      ctx.fillStyle = "#3a2418";
      ctx.fillRect(px + 12, py + 6, 8, 4);
      return;
    }
    const F = Assets.F;
    const fr = playerFrame(p);
    drawShadow(px + 16, py + 27, 11);
    // 프레임 내 발 위치(y=28)를 타일 하단에 맞춘다
    ctx.drawImage(fr, 0, 0, fr.width, fr.height, px + 16 - fr.width, py + 27 - 56, fr.width * 2, fr.height * 2);
  }

  function drawEnemyWorld(ox, oy, en) {
    const m = MONSTERS[en.id];
    const px = ox + en.x * TILE, py = oy + en.y * TILE;
    if (!GFX.on) { drawMob(ctx, px + 16, py + 16, m); return; }
    const F = Assets.F;
    const set = F.slimeTint(m.color);
    const bob = Math.sin(state.time * 3 + (en.seed || 0) * 7);
    const fr = set.move[Math.floor(state.time * 6 + (en.seed || 0)) % set.move.length] || set.move[0];
    const sc = m.boss ? 1.5 : m.titled ? 1.25 : 1;
    const w = 34 * sc, h = 34 * sc;
    drawShadow(px + 16, py + 27, 11 * sc);
    ctx.drawImage(fr, 0, 0, fr.width, fr.height, px + 16 - w / 2, py + 28 - h + bob * 1.5, w, h);
    if (m.kind === "권속") {
      ctx.strokeStyle = "#e6c15a"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px + 16, py + 24, 15 + bob, 0, Math.PI * 2); ctx.stroke();
    }
    if (m.kind === "칭호") {
      ctx.strokeStyle = "#fff3a0"; ctx.lineWidth = 3;
      ctx.strokeRect(px + 16 - 17, py + 2, 34, 26);
    }
    if (m.boss) {
      ctx.strokeStyle = "#c44536"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(px + 16, py + 22, 18 + bob, 0, Math.PI * 2); ctx.stroke();
    }
  }

  const NPC_STYLE = {
    "잔신의 촌장":  { kind: "person", color: "#b8894a" },
    "파편 수집가":  { kind: "person", color: "#7c8a5a" },
    "왕도의 전령":  { kind: "person", color: "#7a5a9a" },
    "빈 자리":      { kind: "ghost",  color: "#5a6070" },
    "궤도 광인":    { kind: "person", color: "#c07a50" },
    "실 쥔 아이":   { kind: "person", color: "#c9a227" },
    "달력 돌":      { kind: "stele",  color: "#8a97a4" },
    "축이 빈 비석": { kind: "stele",  color: "#9aa8b5" },
    "문 없는 문짝": { kind: "door",   color: "#8a6a48" },
    "낙서 우물":    { kind: "well",   color: "#4a7088", small: true },
    "갈래 우물":    { kind: "well",   color: "#4a7088" },
    "북동 오솔길 표지": { kind: "sign", color: "#8a6136" },
    "기성 표지석":   { kind: "stele", color: "#9aa8b5" },
    "재의 왕좌":    { kind: "portal", color: "#e07030" },
    "이름 없는 해안":{ kind: "portal", color: "#50a0c8" },
    "뿌리의 속삭임":{ kind: "portal", color: "#7ab060" },
    "먼지의 부랑":  { kind: "rock",   color: "#a09070" },
    "등대 유품":    { kind: "rock",   color: "#c8b060" },
    "내려온 조각":  { kind: "crystal", color: "#f0b040" },
    "지워진 해의 자리": { kind: "hallow", color: "#e6c15a" },
    "개연의 제단":  { kind: "altar",  color: "#c8b0e0" },
  };

  function drawNPC(ox, oy, n) {
    const px = ox + n.x * TILE, py = oy + n.y * TILE;
    const st = NPC_STYLE[n.name] || { kind: "person", color: "#9a8f78" };
    const F = Assets.F;
    const cx = px + 16, feetY = py + 28;

    if (!GFX.on) {
      ctx.fillStyle = st.color;
      ctx.fillRect(px + 8, py + 10, 16, 16);
    } else if (st.kind === "person") {
      const set = F.personTint(st.color);
      const fr = set.idle[Math.floor(state.time * 1.4) % 2 === 0 ? 0 : 3] || set.idle[0];
      drawShadow(cx, feetY - 1, 11);
      ctx.drawImage(fr, 0, 0, fr.width, fr.height, cx - fr.width, feetY - 56, fr.width * 2, fr.height * 2);
    } else if (st.kind === "ghost") {
      const set = F.personTint(st.color);
      const fr = set.idle[0];
      ctx.globalAlpha = 0.45 + 0.15 * Math.sin(state.time * 2);
      drawShadow(cx, feetY - 1, 10);
      ctx.drawImage(fr, 0, 0, fr.width, fr.height, cx - fr.width, feetY - 60 + Math.sin(state.time * 2) * 2, fr.width * 2, fr.height * 2);
      ctx.globalAlpha = 1;
    } else if (st.kind === "well") {
      const sc = st.small ? 0.8 : 1;
      drawShadow(cx, feetY, 14 * sc);
      const w = F.well, ww = 36 * 2 * sc * 0.75;
      ctx.drawImage(w, 0, 0, w.width, w.height, cx - ww / 2, feetY - 26 * sc - 4, ww, 26 * 2 * sc * 0.75);
      // 우물 물결
      const g = 0.4 + 0.3 * Math.sin(state.time * 3);
      ctx.fillStyle = `rgba(120,180,230,${g * 0.35})`;
      ctx.fillRect(cx - 7 * sc, feetY - 16 * sc, 14 * sc, 2);
    } else if (st.kind === "sign") {
      drawShadow(cx, feetY, 8);
      ctx.fillStyle = "#6b4a2b"; ctx.fillRect(cx - 2, feetY - 24, 4, 22);
      ctx.fillStyle = "#8a6136"; ctx.fillRect(cx - 11, feetY - 24, 22, 12);
      ctx.strokeStyle = "#3a2a1a"; ctx.lineWidth = 2;
      ctx.strokeRect(cx - 11, feetY - 24, 22, 12);
      ctx.fillStyle = "#3a2a1a";
      ctx.fillRect(cx - 7, feetY - 20, 12, 2);
      ctx.fillRect(cx - 7, feetY - 16, 8, 2);
    } else if (st.kind === "stele") {
      drawShadow(cx, feetY, 10);
      ctx.drawImage(F.stele, 0, 0, F.stele.width, F.stele.height, cx - 20, feetY - 30, 40, 60);
      const g = 0.35 + 0.3 * Math.sin(state.time * 2.5);
      ctx.fillStyle = `rgba(159,182,200,${g * 0.5})`;
      ctx.fillRect(cx - 5, feetY - 22, 10, 2);
      ctx.fillRect(cx - 3, feetY - 18, 6, 2);
    } else if (st.kind === "door") {
      drawShadow(cx, feetY, 11);
      ctx.drawImage(F.tiles.door, 0, 0, 16, 16, cx - 14, feetY - 28, 28, 28);
      ctx.strokeStyle = "rgba(230,193,90," + (0.25 + 0.2 * Math.sin(state.time * 2)) + ")";
      ctx.lineWidth = 2;
      ctx.strokeRect(cx - 14, feetY - 28, 28, 28);
    } else if (st.kind === "portal") {
      const r = 16 + Math.sin(state.time * 3) * 2;
      drawShadow(cx, feetY, 15);
      const grad = ctx.createRadialGradient(cx, feetY - 12, 2, cx, feetY - 12, r);
      grad.addColorStop(0, "rgba(255,255,255,.85)");
      grad.addColorStop(0.4, st.color + "cc");
      grad.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.ellipse(cx, feetY - 12, r, r * 1.15, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = st.color; ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) {
        const rr = r - 4 - i * 5 - (state.time * 10 % 5);
        if (rr < 3) continue;
        ctx.beginPath(); ctx.ellipse(cx, feetY - 12, rr, rr * 1.1, state.time + i, 0, Math.PI * 1.5); ctx.stroke();
      }
    } else if (st.kind === "crystal") {
      drawShadow(cx, feetY, 12);
      const gl = 0.5 + 0.4 * Math.sin(state.time * 4);
      ctx.drawImage(F.props.crystal, 0, 0, F.props.crystal.width, F.props.crystal.height, cx - 17, feetY - 34, 34, 36);
      ctx.fillStyle = `rgba(255,220,140,${gl * 0.35})`;
      ctx.beginPath(); ctx.arc(cx, feetY - 16, 22, 0, Math.PI * 2); ctx.fill();
    } else if (st.kind === "rock") {
      drawShadow(cx, feetY, 13);
      ctx.drawImage(F.props.rock, 0, 0, F.props.rock.width, F.props.rock.height, cx - 20, feetY - 26, 40, 30);
    } else if (st.kind === "hallow") {
      const r = 18 + Math.sin(state.time * 2) * 3;
      const grad = ctx.createRadialGradient(cx, feetY - 10, 2, cx, feetY - 10, r + 8);
      grad.addColorStop(0, "rgba(255,244,200,.8)");
      grad.addColorStop(0.5, "rgba(230,193,90,.35)");
      grad.addColorStop(1, "rgba(230,193,90,0)");
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.ellipse(cx, feetY - 10, r + 8, r, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "rgba(255,244,200,.7)"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(cx, feetY - 10, r * 0.7, r * 0.4, 0, 0, Math.PI * 2); ctx.stroke();
    } else if (st.kind === "altar") {
      ctx.drawImage(F.tiles.carpet[0], 0, 0, 16, 16, px - 6, py - 6, 44, 44);
      drawShadow(cx, py + 12, 13);
      ctx.drawImage(F.props.crystal, 0, 0, F.props.crystal.width, F.props.crystal.height, cx - 17, py - 18, 34, 36);
      const gl = 0.4 + 0.3 * Math.sin(state.time * 3);
      ctx.fillStyle = `rgba(200,176,224,${gl * 0.4})`;
      ctx.beginPath(); ctx.arc(cx, py, 26, 0, Math.PI * 2); ctx.fill();
    }

    // 이름표
    const label = n.name;
    ctx.font = "bold 11px sans-serif";
    const tw = ctx.measureText(label).width;
    const ly = st.kind === "person" || st.kind === "ghost" ? py - 14 : py - 22;
    ctx.fillStyle = "rgba(10,8,6,.72)";
    ctx.fillRect(cx - tw / 2 - 5, ly - 11, tw + 10, 15);
    ctx.strokeStyle = "rgba(230,193,90,.45)";
    ctx.lineWidth = 1;
    ctx.strokeRect(cx - tw / 2 - 5, ly - 11, tw + 10, 15);
    ctx.fillStyle = "#f4ead4";
    ctx.textAlign = "center";
    ctx.fillText(label, cx, ly);
    ctx.textAlign = "left";
  }

  /* E 상호작용 힌트 */
  function drawInteractHint(ox, oy) {
    if (state.screen !== "play") return;
    const p = state.player;
    const nx = Math.round(p.x), ny = Math.round(p.y);
    let target = null;
    const npc = state.npcs.find(n => Math.abs(n.x - nx) + Math.abs(n.y - ny) <= 1);
    if (npc) target = { x: npc.x, y: npc.y, label: npc.name };
    const ch = state.chests.find(c => !c.open && Math.abs(c.x - nx) + Math.abs(c.y - ny) <= 1);
    if (!target && ch) target = { x: ch.x, y: ch.y, label: "열기" };
    if (!target && state.stairs && Math.abs(state.stairs.x - nx) + Math.abs(state.stairs.y - ny) <= 1)
      target = { x: state.stairs.x, y: state.stairs.y, label: state.floor < 3 ? "내려가기" : "숲으로" };
    if (!target) return;
    const px = ox + target.x * TILE + 16;
    const py = oy + target.y * TILE - 34 + Math.sin(state.time * 4) * 2.5;
    ctx.fillStyle = "#f4ead4";
    ctx.strokeStyle = "#5a3a18"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(px - 10, py - 10, 20, 20, 4); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#5a3a18";
    ctx.font = "bold 12px sans-serif"; ctx.textAlign = "center";
    ctx.fillText("E", px, py + 4);
    ctx.textAlign = "left";
  }

  /* 파티클/토스트 */
  function drawFX() {
    const F = Assets.F;
    state.fx.dusts.forEach(d => {
      const t = d.t;
      if (t < 0) return;
      const a = 1 - t / 0.45;
      ctx.globalAlpha = a * 0.85;
      if (GFX.on && F.dust) {
        const fr = F.dust[Math.min(3, Math.floor(t / 0.45 * 4))];
        ctx.drawImage(fr, 0, 0, 12, 12, d.x - 8, d.y - 8 - t * 18, 16, 16);
      } else {
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.arc(d.x, d.y - t * 18, 5 * a, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    });
    state.fx.dmgs.forEach(d => {
      const a = 1 - d.t / 0.9;
      const size = d.crit ? 30 : 22;
      ctx.globalAlpha = Math.min(1, a * 2);
      ctx.font = `bold ${size}px sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(0,0,0,.8)";
      ctx.strokeText(d.v, d.x, d.y - d.t * 42);
      ctx.fillStyle = d.crit ? "#8fd0ff" : "#ffd23e";
      ctx.fillText(d.v, d.x, d.y - d.t * 42);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    });
  }
  function drawToasts() {
    state.fx.toasts.forEach((t, i) => {
      const a = t.t < 0.2 ? t.t / 0.2 : t.t > 2.1 ? 1 - (t.t - 2.1) / 0.5 : 1;
      const y = 96 + i * 40;
      ctx.globalAlpha = Math.max(0, a);
      ctx.font = "bold 14px sans-serif";
      const w = ctx.measureText(t.msg).width + 44;
      const x = W / 2 - w / 2;
      ctx.fillStyle = "rgba(16,11,7,.88)";
      ctx.beginPath(); ctx.roundRect(x, y, w, 32, 6); ctx.fill();
      ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.roundRect(x, y, w, 32, 6); ctx.stroke();
      ctx.fillStyle = "#c9a227";
      ctx.fillText("◆", x + 14, y + 21);
      ctx.fillStyle = "#f4ead4";
      ctx.fillText(t.msg, x + 30, y + 21);
      ctx.globalAlpha = 1;
    });
  }

  /* 환경광/비네트 */
  function drawAmbient(m) {
    const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.85);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, m.kind === "town" ? "rgba(8,14,30,.42)" : "rgba(0,0,0,.55)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    if (m.kind === "dungeon") {
      const warm = ctx.createRadialGradient(W / 2, H * 0.28, 20, W / 2, H * 0.28, H * 0.7);
      warm.addColorStop(0, "rgba(255,170,80,.05)");
      warm.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = warm;
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* 폴백 몹 도형 */
  function drawMob(ctx, x, y, m) {
    if (!m) return;
    const r = m.boss ? 16 : m.titled ? 13 : 10;
    ctx.fillStyle = m.color;
    ctx.beginPath();
    if (m.shape === "tri") {
      ctx.moveTo(x, y - r); ctx.lineTo(x + r, y + r); ctx.lineTo(x - r, y + r); ctx.closePath();
    } else if (m.shape === "sq") {
      ctx.rect(x - r, y - r, r * 2, r * 2);
    } else if (m.shape === "dia") {
      ctx.moveTo(x, y - r); ctx.lineTo(x + r, y); ctx.lineTo(x, y + r); ctx.lineTo(x - r, y); ctx.closePath();
    } else if (m.shape === "wolf") {
      ctx.ellipse(x, y, r + 2, r - 2, 0, 0, Math.PI * 2);
    } else {
      ctx.arc(x, y, r, 0, Math.PI * 2);
    }
    ctx.fill();
    if (m.kind === "권속") {
      ctx.strokeStyle = "#e6c15a"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, r + 4, 0, Math.PI * 2); ctx.stroke();
      ctx.lineWidth = 1;
    }
    if (m.kind === "칭호") {
      ctx.strokeStyle = "#fff3a0"; ctx.lineWidth = 3;
      ctx.strokeRect(x - r - 3, y - r - 3, (r + 3) * 2, (r + 3) * 2);
      ctx.lineWidth = 1;
    }
    if (m.boss) {
      ctx.strokeStyle = "#c44536"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(x, y, r + 6, 0, Math.PI * 2); ctx.stroke();
      ctx.lineWidth = 1;
    }
  }

  function tileColor(t, x, y, grass) {
    if (t === 1) return "#3a322c";
    if (t === 2) return "#6a5a48";
    if (t === 3) return "#2a6a88";
    if (t === 4) return "#2a1810";
    if (t === 5) return "#245028";
    if (t === 6) return "#9a8a72";
    if (t === 7) return "#7a8894";
    const n = (x * 13 + y * 7) % 5;
    return n === 0 ? "#4a8a3a" : n === 1 ? "#3f7a34" : grass;
  }

  function draw() {
    ctx.fillStyle = "#08070c";
    ctx.fillRect(0, 0, W, H);
    if (state.screen === "title") { drawTitle(); drawToasts(); return; }
    if (state.screen === "battle") { drawBattle(); drawToasts(); return; }
    if (state.screen === "win") { drawWin(); drawToasts(); return; }
    drawWorld();
    if (state.screen === "dialog") drawDialog();
    drawToasts();
    drawFade();
  }

  function drawFade() {
    if (!state.pendingTravel) return;
    const t = Math.min(state.pendingTravel.t, 0.7);
    ctx.fillStyle = "rgba(4,3,2," + Math.sin(Math.PI * t / 0.7).toFixed(3) + ")";
    ctx.fillRect(0, 0, W, H);
  }

  /* ---------- 타이틀 ---------- */
  function drawTitle() {
    const F = Assets.F;
    // 하늘
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#101828");
    sky.addColorStop(0.45, "#1c2a3e");
    sky.addColorStop(0.7, "#2a3a44");
    sky.addColorStop(1, "#1a2620");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);
    // 달
    ctx.fillStyle = "rgba(240,230,200,.9)";
    ctx.beginPath(); ctx.arc(W * 0.78, 130, 46, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(240,230,200,.12)";
    ctx.beginPath(); ctx.arc(W * 0.78, 130, 74, 0, Math.PI * 2); ctx.fill();
    // 별
    for (let i = 0; i < 60; i++) {
      const sx = (i * 97 + 31) % W, sy = (i * 61) % 300;
      const tw2 = 0.3 + 0.7 * Math.abs(Math.sin(state.time * 1.5 + i));
      ctx.fillStyle = `rgba(230,240,255,${tw2 * 0.7})`;
      ctx.fillRect(sx, sy, 2, 2);
    }
    // 지평선: 물
    if (GFX.on && F.waterOk) {
      const wf = F.water[Math.floor(state.time * 4) % 6];
      for (let x = 0; x < W; x += TILE) for (let y = H - TILE * 3; y < H; y += TILE)
        ctx.drawImage(wf, 0, 0, 16, 16, x, y, TILE, TILE);
      // 달 반사
      ctx.fillStyle = "rgba(240,230,200,.10)";
      ctx.fillRect(W * 0.78 - 40, H - TILE * 3, 80, TILE * 3);
    } else {
      ctx.fillStyle = "#1d3a55"; ctx.fillRect(0, H - TILE * 3, W, TILE * 3);
    }
    // 강가 잔디
    if (GFX.on) {
      for (let x = 0; x < W; x += TILE) {
        ctx.drawImage(F.tiles.grass[(x / TILE) % F.tiles.grass.length], 0, 0, 16, 16, x, H - TILE * 4, TILE, TILE);
      }
      // 좌우 나무
      if (F.props.treeClump) {
        ctx.drawImage(F.props.treeClump, 0, 0, 64, 48, -30, H - TILE * 4 - 88, 192, 144);
        ctx.drawImage(F.props.treeClump, 0, 0, 64, 48, W - 150, H - TILE * 4 - 80, 180, 136);
      }
      // 걷는 여행자
      const fr = F.player.walk.down[Math.floor(state.time * 8) % 6];
      const wx = (state.time * 46) % (W + 80) - 40;
      ctx.drawImage(fr, 0, 0, fr.width, fr.height, wx, H - TILE * 4 - 46, fr.width * 2, fr.height * 2);
    }
    // 제목
    ctx.textAlign = "center";
    ctx.font = "bold 58px serif";
    ctx.fillStyle = "rgba(0,0,0,.6)";
    ctx.fillText("극 · 에코 오브 아스안", W / 2 + 4, 104 + 4);
    const tg = ctx.createLinearGradient(0, 60, 0, 120);
    tg.addColorStop(0, "#f8ecca"); tg.addColorStop(0.55, "#e6c15a"); tg.addColorStop(1, "#b8894a");
    ctx.fillStyle = tg;
    ctx.fillText("극 · 에코 오브 아스안", W / 2, 104);
    ctx.font = "15px sans-serif";
    ctx.fillStyle = "#9aa8b5";
    ctx.fillText("마을에서 우주·다중차원을 지나, 그 위 극까지. 신은 가능과 불가능의 기초. 악성 일곱이 급마다 핀다.", W / 2, 140);
    ctx.textAlign = "left";

    // 스토리 카드
    STORIES.forEach((s, i) => {
      const y = 180 + i * 100;
      const hov = state.hover === i;
      ctx.fillStyle = hov ? "rgba(38,30,20,.95)" : "rgba(18,14,10,.88)";
      ctx.beginPath(); ctx.roundRect(240, y, W - 480, 84, 8); ctx.fill();
      ctx.strokeStyle = hov ? "#e6c15a" : s.color;
      ctx.lineWidth = hov ? 3 : 2;
      ctx.beginPath(); ctx.roundRect(240, y, W - 480, 84, 8); ctx.stroke();
      // 포탈 엠블럼
      const pcx = 290, pcy = y + 42;
      const grad = ctx.createRadialGradient(pcx, pcy, 2, pcx, pcy, 26);
      grad.addColorStop(0, "rgba(255,255,255,.8)");
      grad.addColorStop(0.5, s.color + "aa");
      grad.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(pcx, pcy, 26 + Math.sin(state.time * 3) * 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#efe8d8";
      ctx.font = "bold 24px serif";
      ctx.fillText(s.title, 340, y + 38);
      ctx.font = "14px sans-serif";
      ctx.fillStyle = "#cfc6b4";
      ctx.fillText(s.blurb, 340, y + 64);
      if (hov) {
        ctx.fillStyle = "#e6c15a";
        ctx.font = "bold 13px sans-serif";
        ctx.textAlign = "right";
        ctx.fillText("클릭 또는 Enter ▶", W - 260, y + 68);
        ctx.textAlign = "left";
      }
    });
    ctx.fillStyle = "#6a7a88";
    ctx.font = "13px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("WASD 이동 · E/스페이스 상호작용 · 전투 1–4 · I 가방 · Q 퀘스트 · M 지역", W / 2, H - 14);
    ctx.textAlign = "left";
  }

  function drawDialog() {
    const d = state.dialog;
    const bx = 40, by = H - 170, bw = W - 80, bh = 140;
    // 목제 패널
    if (GFX.on && Assets.F.tiles.wood) {
      for (let x = 0; x < bw; x += TILE) for (let y = 0; y < bh; y += TILE)
        ctx.drawImage(Assets.F.tiles.wood[0], 0, 0, 16, 16, bx + x, by + y, TILE, TILE);
      ctx.fillStyle = "rgba(10,7,4,.55)";
      ctx.fillRect(bx, by, bw, bh);
    } else {
      ctx.fillStyle = "rgba(8,7,12,.85)";
      ctx.fillRect(bx, by, bw, bh);
    }
    ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 3;
    ctx.strokeRect(bx, by, bw, bh);
    ctx.strokeStyle = "rgba(90,58,24,.9)"; ctx.lineWidth = 7;
    ctx.strokeRect(bx - 4, by - 4, bw + 8, bh + 8);
    // 화자 네임플레이트
    ctx.font = "bold 16px serif";
    const nw = ctx.measureText(d.who).width + 28;
    ctx.fillStyle = "#2a1c12";
    ctx.beginPath(); ctx.roundRect(bx + 16, by - 16, nw, 32, 5); ctx.fill();
    ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(bx + 16, by - 16, nw, 32, 5); ctx.stroke();
    ctx.fillStyle = "#e6c15a";
    ctx.fillText(d.who, bx + 30, by + 6);
    // 대사
    ctx.fillStyle = "#f4ead4";
    ctx.font = "17px sans-serif";
    wrapText(d.lines[d.i], bx + 28, by + 46, bw - 56, 24);
    // 계속 표시
    ctx.fillStyle = "#9a8f78";
    ctx.font = "12px sans-serif";
    const blink = Math.floor(state.time * 2) % 2 === 0;
    if (blink) ctx.fillText("▼ 스페이스로 계속", bx + 28, by + bh - 14);
  }
  function wrapText(text, x, y, maxW, lh) {
    const words = text.split(" ");
    let line = "", yy = y;
    const chunks = [];
    // 한글은 글자 단위로도 끊는다
    let cur = "";
    for (const w of words) {
      const test = line ? line + " " + w : w;
      if (ctx.measureText(test).width > maxW) {
        if (line) chunks.push(line);
        // 단어 자체가 길면 글자 단위
        if (ctx.measureText(w).width > maxW) {
          for (const ch of w) {
            if (ctx.measureText(cur + ch).width > maxW) { chunks.push(cur); cur = ch; }
            else cur += ch;
          }
          line = cur; cur = "";
        } else line = w;
      } else line = test;
    }
    if (line) chunks.push(line);
    chunks.slice(0, 4).forEach((c, i) => ctx.fillText(c, x, yy + i * lh));
  }

  /* ---------- 전투 ---------- */
  function drawBattle() {
    const b = state.battle, p = state.player, c = pal();
    if (!b) return;
    const F = Assets.F;

    // 배경 — 지역별
    if (GFX.on) {
      if (state.area === "dungeon") {
        for (let x = 0; x < W; x += TILE) for (let y = 0; y < H; y += TILE)
          ctx.drawImage(F.tiles.wood[0], 0, 0, 16, 16, x, y, TILE, TILE);
        ctx.fillStyle = "rgba(12,8,5,.5)";
        ctx.fillRect(0, 0, W, H);
      } else {
        for (let x = 0; x < W; x += TILE) for (let y = 0; y < H; y += TILE)
          ctx.drawImage(F.tiles.grass[((x + y) / TILE | 0) % F.tiles.grass.length], 0, 0, 16, 16, x, y, TILE, TILE);
        ctx.fillStyle = state.area === "forest" ? "rgba(10,26,14,.5)" : "rgba(20,32,18,.35)";
        ctx.fillRect(0, 0, W, H);
      }
    } else {
      ctx.fillStyle = c.floor; ctx.fillRect(0, 0, W, H);
    }
    const vg = ctx.createRadialGradient(W / 2, H / 2, 200, W / 2, H / 2, 760);
    vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,.5)");
    ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);

    const sh = state.fx.shake;
    ctx.save();
    if (sh) ctx.translate(Math.sin(state.time * 80) * sh, Math.cos(state.time * 60) * sh * 0.7);

    /* 적 */
    const ex = W * 0.66, ey = H * 0.52;
    const m = b.m;
    const esc = m.boss ? 4.4 : m.titled ? 3.6 : 3.2;
    if (GFX.on) {
      const set = F.slimeTint(m.color);
      let fr;
      if (b.eHit > 0.25) fr = set.hit[0];
      else if (b.eAnim > 0) fr = set.atk[Math.floor(state.time * 14) % set.atk.length];
      else fr = set.idle[Math.floor(state.time * 3.2) % set.idle.length];
      const w = fr.width * esc, h = fr.height * esc;
      const lunge = b.eAnim > 0 ? Math.sin(b.eAnim * 6) * 34 : 0;
      const bob = Math.sin(state.time * 2.4) * 5;
      drawShadow(ex + lunge * 0.4, ey + h * 0.42, w * 0.42);
      if (b.eHit > 0.3) ctx.globalAlpha = 0.55 + 0.45 * Math.sin(state.time * 40);
      ctx.drawImage(fr, 0, 0, fr.width, fr.height, ex - w / 2 + lunge, ey - h / 2 + bob, w, h);
      ctx.globalAlpha = 1;
      // 등급 오라
      if (m.kind === "권속") {
        ctx.strokeStyle = "#e6c15a"; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.arc(ex + lunge * 0.4, ey + bob * 0.5, w * 0.52, 0, Math.PI * 2); ctx.stroke();
      }
      if (m.kind === "칭호") {
        ctx.strokeStyle = "#fff3a0"; ctx.lineWidth = 5;
        ctx.strokeRect(ex - w * 0.55, ey - h * 0.55, w * 1.1, h * 1.1);
      }
      if (m.boss) {
        ctx.strokeStyle = "#c44536"; ctx.lineWidth = 5;
        ctx.beginPath(); ctx.arc(ex, ey + bob * 0.5, w * 0.56, 0, Math.PI * 2); ctx.stroke();
      }
    } else {
      ctx.fillStyle = m.color;
      ctx.beginPath(); ctx.arc(ex, ey, m.boss ? 70 : 48, 0, Math.PI * 2); ctx.fill();
    }

    /* 플레이어 */
    const pxp = W * 0.30, pyp = H * 0.55;
    if (GFX.on) {
      const attacking = b.pAtkT >= 0;
      const dir = attacking ? "up" : "up";
      let frs = attacking ? F.player.atk[dir] : F.player.idle.up;
      let fr = attacking ? frs[Math.min(frs.length - 1, Math.floor(b.pAtkT / 0.5 * 4))] : frs[Math.floor(state.time * 1.8) % 2 === 0 ? 0 : 3];
      const dash = attacking ? Math.sin(Math.min(1, b.pAtkT / 0.5) * Math.PI) * 60 : 0;
      const sc = 3;
      const w = fr.width * sc, h = fr.height * sc;
      drawShadow(pxp + dash, pyp + h * 0.4, w * 0.32);
      ctx.drawImage(fr, 0, 0, fr.width, fr.height, pxp + dash - w / 2, pyp - h / 2, w, h);
      // 스킬 이펙트
      if (b.pSkillT >= 0) {
        const t = b.pSkillT / 0.6;
        ctx.strokeStyle = `rgba(140,200,255,${1 - t})`;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(ex, ey, 60 + t * 90, -0.6 + t * 2, 0.9 + t * 2);
        ctx.stroke();
        ctx.strokeStyle = `rgba(255,255,255,${(1 - t) * 0.8})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(ex, ey, 40 + t * 110, -0.4 + t * 2.4, 1.1 + t * 2.4);
        ctx.stroke();
      }
    } else {
      ctx.fillStyle = "#2a4068";
      ctx.fillRect(pxp - 20, pyp - 30, 40, 60);
    }

    ctx.restore();

    /* 적 정보 */
    ctx.textAlign = "center";
    ctx.font = "bold 24px serif";
    ctx.lineWidth = 5; ctx.strokeStyle = "rgba(0,0,0,.75)";
    ctx.strokeText(m.name, W / 2, 78);
    ctx.fillStyle = "#f4ead4";
    ctx.fillText(m.name, W / 2, 78);
    // 종족 배지
    ctx.font = "bold 12px sans-serif";
    const badge = m.kind === "권속" ? "권속 · 금 고리" : m.kind === "칭호" ? "칭호 · 금 각" : m.kind === "형상" ? "악성 형상" : "정석";
    ctx.fillStyle = m.kind === "정석" ? "#9aa8b5" : "#e6c15a";
    ctx.fillText(badge, W / 2, 100);
    // HP바
    const bw2 = 420, bx2 = W / 2 - bw2 / 2, by2 = 116;
    ctx.fillStyle = "#120c0c";
    ctx.fillRect(bx2 - 3, by2 - 3, bw2 + 6, 20);
    ctx.fillStyle = "#3a1414";
    ctx.fillRect(bx2, by2, bw2, 14);
    const hpR = Math.max(0, b.ehp) / m.hp;
    const hpg = ctx.createLinearGradient(bx2, 0, bx2 + bw2, 0);
    hpg.addColorStop(0, "#e0563e"); hpg.addColorStop(1, "#c44536");
    ctx.fillStyle = hpg;
    ctx.fillRect(bx2, by2, bw2 * hpR, 14);
    ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 2;
    ctx.strokeRect(bx2 - 3, by2 - 3, bw2 + 6, 20);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 12px sans-serif";
    ctx.fillText(`HP ${Math.max(0, b.ehp)} / ${m.hp}`, W / 2, by2 + 11);
    ctx.textAlign = "left";

    /* 전투 로그 */
    ctx.font = "16px sans-serif";
    const lw = ctx.measureText(b.log).width;
    ctx.fillStyle = "rgba(10,7,4,.7)";
    ctx.beginPath(); ctx.roundRect(W / 2 - lw / 2 - 16, 356, lw + 32, 30, 5); ctx.fill();
    ctx.fillStyle = "#f4ead4"; ctx.textAlign = "center";
    ctx.fillText(b.log, W / 2, 376);
    ctx.textAlign = "left";

    /* 행동 버튼 */
    const acts = [
      { k: "atk", label: "1 공격", sub: "검을 휘른다" },
      { k: "skill", label: "2 스킬", sub: "MP 4" },
      { k: "item", label: "3 아이템", sub: "약초" },
      { k: "run", label: "4 도망", sub: "55%" },
    ];
    let hoverIdx = -1;
    acts.forEach((a, i) => {
      const bx = 80 + i * 200, by = 450, bwid = 180, bht = 50;
      const hov = state.mouse.x >= bx && state.mouse.x <= bx + bwid && state.mouse.y >= by && state.mouse.y <= by + bht;
      if (hov) hoverIdx = i;
      ctx.fillStyle = hov ? "#3a2a18" : "#1a140e";
      ctx.beginPath(); ctx.roundRect(bx, by, bwid, bht, 6); ctx.fill();
      ctx.strokeStyle = hov ? "#e6c15a" : "#8a6a30";
      ctx.lineWidth = hov ? 3 : 2;
      ctx.beginPath(); ctx.roundRect(bx, by, bwid, bht, 6); ctx.stroke();
      ctx.fillStyle = "#f4ead4";
      ctx.font = "bold 16px sans-serif";
      ctx.fillText(a.label, bx + 16, by + 22);
      ctx.fillStyle = "#9a8f78";
      ctx.font = "11px sans-serif";
      ctx.fillText(a.sub, bx + 16, by + 40);
      if (hov) { ctx.fillStyle = "#e6c15a"; ctx.fillText("▶", bx + bwid - 22, by + 30); }
    });
    b.hoverBtn = hoverIdx;

    drawFX();
  }

  function drawWin() {
    // 배경 브라
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#1a1610"); g.addColorStop(1, "#0a0806");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const F = Assets.F;
    // 빛기둥
    const lg = ctx.createLinearGradient(0, 0, 0, H);
    lg.addColorStop(0, "rgba(230,193,90,.22)"); lg.addColorStop(1, "rgba(230,193,90,0)");
    ctx.fillStyle = lg;
    ctx.fillRect(W / 2 - 140, 0, 280, H);
    if (GFX.on && F.props.crystal) {
      ctx.drawImage(F.props.crystal, 0, 0, F.props.crystal.width, F.props.crystal.height, W / 2 - 60, 90, 120, 126);
    }
    ctx.textAlign = "center";
    ctx.font = "bold 40px serif";
    ctx.fillStyle = "#e6c15a";
    ctx.fillText("악성을 봉인했다", W / 2, 300);
    ctx.font = "18px sans-serif";
    ctx.fillStyle = "#cfc6b4";
    const relicName = state.player.relic && ITEMS[state.player.relic] ? ITEMS[state.player.relic].name : "";
    ctx.fillText(state.story.title + (relicName ? " — " + relicName : ""), W / 2, 348);
    ctx.fillStyle = "#9a8f78";
    ctx.font = "16px sans-serif";
    ctx.fillText("극이 한번 눈을 떴다. 침묵은 그대로다. 세 입구를 모두 지나면 극의 문이 열린다.", W / 2, 396);
    const blink = Math.floor(state.time * 2) % 2 === 0;
    if (blink) {
      ctx.fillStyle = "#e6c15a";
      ctx.fillText("Enter — 다른 입구로", W / 2, 450);
    }
    ctx.textAlign = "left";
  }

  function drawMini(m, p) {
    const mm = document.getElementById("minimap");
    if (!mm) return;
    const mx = mm.getContext("2d");
    const s = mm.width / Math.max(m.cols, m.rows);
    mx.fillStyle = "#142010";
    mx.fillRect(0, 0, mm.width, mm.height);
    for (let y = 0; y < m.rows; y++) for (let x = 0; x < m.cols; x++) {
      const t = m.tiles[y][x];
      mx.fillStyle = t === 1 ? (m.kind === "dungeon" ? "#3a3a44" : "#2e4a26") : t === 5 ? "#1a4a20" : t === 6 ? "#a08a5a" : t === 3 ? "#2a5a80" : t === 2 ? "#6a5a40" : t === 7 ? "#89a" : t === 4 ? "#402a18" : "#3a7a30";
      mx.fillRect(x * s, y * s, s, s);
    }
    state.exits.forEach(e => { mx.fillStyle = "#e6c15a"; mx.fillRect(e.x * s, e.y * s, s, s); });
    state.npcs.forEach(n => { mx.fillStyle = "#e6c15a"; mx.fillRect(n.x * s, n.y * s, s, s); });
    state.chests.forEach(ch => { if (!ch.open) { mx.fillStyle = "#c9a227"; mx.fillRect(ch.x * s, ch.y * s, s, s); } });
    if (state.stairs) { mx.fillStyle = "#fff"; mx.fillRect(state.stairs.x * s, state.stairs.y * s, s, s); }
    mx.fillStyle = "#ff5a4a";
    mx.fillRect(p.x * s - 1, p.y * s - 1, s + 2, s + 2);
  }

  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (state.screen === "battle" && state.battle?.turn === "enemy") {
      state.battle._cd = (state.battle._cd || 0) + dt;
      if (state.battle._cd > 0.7) { state.battle._cd = 0; enemyTurn(); }
    }
    update(dt);
    ctx.imageSmoothingEnabled = false;
    draw();
    requestAnimationFrame(loop);
  }
  renderPanel();
  requestAnimationFrame(loop);
  Assets.boot();

  /* 테스트/디버그 훅 (플레이에 영향 없음) */
  window.__DBG = { state, pickStory, tryInteract, startBattle, battleAct, spawnFloor, GFX, panels, travel: travelFromModal, REGIONS, regionUnlocked };
})();
