# 아트 리소스 — Mystic Woods 적용기록

에셋: **Mystic Woods - 16x16 Pixel Art Asset Pack** (free 2.1)  
저자: Game Endeavor — https://game-endeavor.itch.io/mystic-woods  
라이선스: 비영리 무료. 수정 허용, 재배포·판매 금지 (`assets/CREDITS.txt` 참고).

`skeleton.png`은 무료판에서 **노이즈 플레이스홀더**라 사용하지 않는다.

## 파일 매핑

| 원본 | 용도 |
|------|------|
| `characters/player.png` | 플레이어 4방향 대기/걷기/공격. NPC 실루엣(틴트) |
| `characters/slime.png` | 모든 몬스터(정석/권속/칭호/형상). 색 틴트로 50종 변형 |
| `tilesets/grass.png`, `decor_16x16.png` | 마을/숲 잔디 타일 |
| `tilesets/plains.png` | 마을 경계·숲 나무 군락, 흙길 타일 |
| `tilesets/water1~6.png` | 물 6프레임 애니메이션(은은한 스펙클) |
| `tilesets/walls/walls.png` | 던전 석벽(윗면/앞면 자동 판정) |
| `tilesets/walls/wooden_door.png` | 「문 없는 문짝」 NPC |
| `tilesets/floors/wooden.png`, `carpet.png` | 던전 바닥 + 양탄자 포인트 |
| `tilesets/fences.png` | (예비) 울타리 |
| `objects/objects.png` | 수풀, 바위, 수정(내려온 조각·개연의 제단) |
| `objects/chest_01.png` | 상자 4프레임(닫힘→열림) |
| `particles/dust_particles_01.png` | 타격/이동/상자 먼지 |

절차적 제작(에셋 대체 불가): 우물(`makeWell`), 비석(`makeStele`), 던전 포탈 3색, 지워진 해의 자리 빛.

## 스프라이트 시트 구조 (분석 결과)

**player.png** — 48px 셀 × 6열 × 10밴드. 좌향 기본(우향은 좌수평반전).
- 밴드 0/1/2 = 대기 하/좌/상
- 밴드 3/4/5 = 걷기 하/좌/상
- 밴드 6/7/8/9 = 공격 하/좌/상/우
- 프레임 내 발 앵커: (중앙, y=28)

**slime.png** — 32px 셀 × 7열 × 5밴드 = 대기4 / 이동6 / 공격7 / 피격3 / 여분5프레임.
프레임을 bbox 정규화해 하단 중앙 앵커로 맞춘 뒤 몬스터 색으로 틴트.

**waterN.png** — 6개 파일이 **애니메이션 프레임**. 파일끼리 차이는 미세(물결 스펙클).
셀 (2,0)을 물, 셀 (1,0)을 변형으로 사용. 청록 틴트를 얹어 물빛을 강조.

## 렌더링 파이프라인 (`js/assets.js`)

1. `Assets.boot()` — 이미지 로드(실패해도 게임은 도형 폴백으로 동작)
2. 프레임 추출 → 오프스크린 캔버스 캐시
3. `slimeTint(color)` / `personTint(color)` — 명도 기반 단색 재색칠, 색상별 캐시
4. `buildLayer()` — 층 이동 시 정적 타일을 통짜 캔버스로 미리 합성(마진 96/128px, 나무 처갬 대응)

## 적용 범위

- 타이틀: 밤하늘/달/물/나무/걷는 여행자, 스토리 카드 호버
- 마을: 잔디·흙길·물 애니메이션·나무 경계·목조 집·우물·비석·포탈 3색·불탄 자국 잔불
- 던전: 석벽(윗면/앞면)·나무 바닥·양탄자·수정 장식·내려가기 구멍
- 전투: 배경 타일 + 대형 슬라임(틴트) + 플레이어 공격 모션 + 피격 백색점멸 + 데미지 숫자 + 먼지 + 화면 흔들림 + 스킬 참격
- 피드백: E 상호작용 프롬프트, 토스트, 이동 먼지
