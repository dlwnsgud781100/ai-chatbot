/* game.js + assets.js 런타임 스모크 테스트 (Node, DOM 스텁)
 * 흐름: 타이틀 → 마을 → 북동 출구 → 숲 → 세 입구 → 던전 → 전투 → 지역 이동
 */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

/* ---- 캔버스 2D 스텁 ---- */
function makeCtx() {
  const grad = { addColorStop() {} };
  return new Proxy({}, {
    get(t, k) {
      if (k === "measureText") return (s) => ({ width: String(s).length * 7 });
      if (k === "createLinearGradient" || k === "createRadialGradient" || k === "createPattern") return () => grad;
      if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4).fill(255), width: w, height: h });
      if (k === "putImageData") return () => {};
      if (typeof k === "string" && !(k in t)) t[k] = () => undefined;
      return t[k];
    },
    set(t, k, v) { t[k] = v; return true; },
  });
}
function makeCanvas(id) {
  const el = makeEl(id);
  el.width = 1280; el.height = 720;
  el.getContext = () => makeCtx();
  el.getBoundingClientRect = () => ({ left: 0, top: 0, width: 1280, height: 720 });
  return el;
}
function makeEl(id) {
  const store = {};
  return {
    id, style: store, dataset: {},
    classList: { add() {}, remove() {}, contains: () => false, toggle() {} },
    innerHTML: "", textContent: "",
    addEventListener() {}, removeEventListener() {},
    querySelectorAll: () => [],
    setAttribute() {},
  };
}

const elements = {};
const ids = ["hud","hud-name","hud-lv","hp-fill","hp-text","mp-fill","mp-text","hud-gold",
  "hud-floor","hud-quest","hotbar","win-body","win-modal","win-title","win-close"];
ids.forEach(i => elements[i] = makeEl(i));
elements.minimap = makeCanvas("minimap");
elements.game = makeCanvas("game");

const winListeners = {};
const rafQueue = [];

const sandbox = {
  console,
  Math, Date, Uint8ClampedArray, Promise, Object, Array, JSON, Set, Map, parseInt, parseFloat, String, Number, Boolean, Error,
  performance: { now: () => Date.now() },
  requestAnimationFrame: (cb) => { rafQueue.push(cb); },
  setTimeout: (cb) => cb(),
  document: {
    getElementById: (id) => elements[id] || null,
    createElement: (tag) => makeCanvas(tag),
    querySelectorAll: () => [],
  },
  window: {},
  Image: class {
    constructor() { this._src = ""; }
    set src(v) {
      this._src = v;
      Promise.resolve().then(() => this.onload && this.onload());
    }
    get src() { return this._src; }
  },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
sandbox.window.addEventListener = (ev, cb) => { (winListeners[ev] = winListeners[ev] || []).push(cb); };

vm.createContext(sandbox);

function load(file) {
  const code = fs.readFileSync(path.join(__dirname, "..", "js", file), "utf8");
  vm.runInContext(code, sandbox, { filename: file });
}

process.on("unhandledRejection", (e) => { console.error("UNHANDLED", e); process.exit(1); });

let t = 0;
function frames(n) {
  for (let i = 0; i < n; i++) {
    t += 16.7;
    const q = rafQueue.splice(0);
    if (!q.length) break;
    q.forEach(cb => cb(t));
  }
}
function key(k, down = true) {
  (winListeners[down ? "keydown" : "keyup"] || []).forEach(cb => cb({ key: k, preventDefault() {} }));
}
function closeDialogs(S) { S.screen = "play"; S.dialog = null; }

const failures = [];
function step(name, fn) {
  try { fn(); console.log("✔", name); }
  catch (e) { failures.push(name); console.error("✘", name, "\n   ", e.stack.split("\n").slice(0, 4).join("\n    ")); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || "assertion failed"); }

(async () => {
  load("monsters.js");
  load("assets.js");
  load("game.js");
  const D = sandbox.window.__DBG;
  const S = D.state;

  step("타이틀 렌더 60프레임", () => frames(60));
  step("에셋 로드 대기", async () => { for (let i = 0; i < 50 && !D.GFX.on; i++) { await Promise.resolve(); frames(2); } if (!D.GFX.on) throw new Error("GFX 미활성"); });
  step("스토리 시작 → 아스안 마을", () => {
    D.pickStory(0);
    assert(S.area === "town", "시작 지역은 마을");
    assert(S.player.x === 17 && S.player.y === 18, "시작 위치 (17,18) 중앙 광장");
  });
  step("마을: 포탈 제거 + 주민 21명 분산 배치", () => {
    const gone = ["재의 왕좌", "이름 없는 해안", "뿌리의 속삭임"].every(n => !S.npcs.some(x => x.name === n));
    assert(gone, "마을에 던전 포탈이 없어야 함");
    assert(S.npcs.some(n => n.name === "북동 오솔길 표지"), "오솔길 표지 존재");
    assert(S.exits.length === 1 && S.exits[0].label === "북동 숲" && S.exits[0].x === 46 && S.exits[0].y === 2, "북동 출구 (46,2)");
    assert(S.map.cols === 48 && S.map.rows === 32, "마을 48x32 대형");
    ["잔신의 촌장","대장장이","상인","촌장 부인","촌장 손자","농부","목수","숲지기","어부","파편 수집가"].forEach(n =>
      assert(S.npcs.some(x => x.name === n), "주민 존재: " + n));
    assert(S.npcs.length >= 21, "주민 21명 이상 (현재 " + S.npcs.length + ")");
    // 전원 서 있는 칸은 걸을 수 있는 칸
    S.npcs.forEach(n => {
      const tt = S.map.tiles[n.y][n.x];
      assert(![1, 2, 3].includes(tt), n.name + " 배치 칸 walkable");
    });
    // 몰림 방지: 모든 쌍 거리 ≥ 2
    for (let i = 0; i < S.npcs.length; i++) for (let j = i + 1; j < S.npcs.length; j++) {
      const a = S.npcs[i], b = S.npcs[j];
      const d = Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
      assert(d >= 2, `몰림: ${a.name}-${b.name} 거리 ${d}`);
    }
  });
  step("마을 렌더 + 이동(WASD)", () => { key("d"); frames(90); key("d", false); key("w"); frames(40); key("w", false); });
  step("안개: 시작점만 밝고 미탐험 지역은 검음", () => {
    assert(S.explored[18][17], "시작 칸 탐험됨");
    assert(S.explored[19][17] || S.explored[17][17], "인근 칸 탐험됨");
    assert(!S.explored[2][46], "북동 출구 미탐험");
    assert(!S.explored[30][5], "먼 NPC 칸 미탐험");
    assert(!S.explored[0][0], "맵 가장자리 미탐험");
  });
  step("안개: 걸으면 드러난다", () => {
    S.player.x = 40; S.player.y = 8; frames(3);
    assert(S.explored[8][40], "숲지기 자리 탐험됨");
    assert(!S.explored[2][46], "출구는 여전히 미탐험");
    S.player.x = 17; S.player.y = 18;
  });
  function talkAt(npcName, lines) {
    const n = S.npcs.find(x => x.name === npcName);
    S.player.x = n.x; S.player.y = n.y + 1;
    S.screen = "play"; S.dialog = null;
    D.tryInteract();
    for (let i = 0; i < lines; i++) { key(" "); frames(4); }
  }
  step("퀘스트는 수주 전 비가시", () => {
    assert(S.player.quests.every(q => q.locked), "시작 시 모든 퀘스트 locked");
    assert(!D.panels.quest.includes("심기만 하는 말"), "패널에 서브 안 보임");
    assert(!D.panels.quest.includes("길려진 해의 기성"), "패널에 메인 안 보임");
  });
  step("수주(1): 메인 — 촌장 첫 대화", () => {
    talkAt("잔신의 촌장", 3);
    assert(!S.player.quests.find(q => q.id === "start").locked, "메인 수주됨");
    assert(D.panels.quest.includes("길려진 해의 기성"), "패널에 메인 표시");
  });
  step("수주(2~5): 서브 4종 순차", () => {
    S.player.inv.herb = 0; // 진료 분기 방해 금지
    talkAt("잔신의 촌장", 3); assert(!S.player.quests.find(q => q.id === "scar").locked, "scar");
    talkAt("잔신의 촌장", 3); assert(!S.player.quests.find(q => q.id === "hunt").locked, "hunt");
    talkAt("잔신의 촌장", 3); assert(!S.player.quests.find(q => q.id === "collect").locked, "collect");
    talkAt("잔신의 촌장", 3); assert(!S.player.quests.find(q => q.id === "hooks").locked, "hooks");
    ["접힌 자국의 약", "제단의 잔액", "일곱이 아니라 셋", "심기만 하는 말"].forEach(t =>
      assert(D.panels.quest.includes(t), "패널 표시: " + t));
  });
  step("약초 진료는 수주 후에만 동작", () => {
    S.player.inv.herb = 1;
    talkAt("잔신의 촌장", 2);
    assert(S.player.quests.find(q => q.id === "scar").done, "scar 완료");
    assert(S.player.inv.herb === 0, "약초 소모");
  });
  step("우물 재앙: 발견만 하면 아직 의뢰 아님", () => {
    talkAt("갈래 우물", 3);
    assert(S.player.disasters.well === "open", "재앙 open");
    assert(S.player.quests.find(q => q.id === "well").locked, "well 퀘스트 여전히 locked");
    assert(!D.panels.quest.includes("우물이 사람을 삼킨다"), "패널에 안 보임");
  });
  step("재앙 의뢰는 촌장이 최우선 수주", () => {
    talkAt("잔신의 촌장", 3);
    assert(!S.player.quests.find(q => q.id === "well").locked, "well 수주");
    assert(D.panels.quest.includes("우물이 사람을 삼킨다"), "패널 표시");
  });
  step("하늘 재앙: 광인 → 촌장 수주", () => {
    talkAt("궤도 광인", 3);
    assert(S.player.disasters.sky === "open", "sky open");
    assert(S.player.quests.find(q => q.id === "sky").locked, "sky 아직 locked");
    talkAt("잔신의 촌장", 3);
    assert(!S.player.quests.find(q => q.id === "sky").locked, "sky 수주");
  });
  step("추가 대화: 의뢰 없음(기본 대기)", () => { talkAt("잔신의 촌장", 3); frames(20); });
  step("지역 패널 렌더", () => {
    D.travel("asan"); // 현재 지역 → 토스트만
    assert(D.panels.region.includes("아스안 마을"), "지역 패널에 마을");
    assert(D.panels.region.includes("왕도"), "잠긴 국가급 지역 표시");
    assert(D.panels.region.includes("길려진 해의 기성"), "기성 항목 존재");
  });
  step("북동 출구 → 숲 이동(페이드)", () => {
    closeDialogs(S);
    S.player.x = 46; S.player.y = 2;
    frames(2);
    assert(S.pendingTravel, "출구 밟으면 페이드 시작");
    frames(60);
    assert(S.area === "forest", "숲 도착");
    assert(S.player.visited.has("forest"), "숲 방문 기록");
  });
  step("숲: 세 입구 + 표지석 + 몹", () => {
    frames(60);
    ["재의 왕좌", "이름 없는 해안", "뿌리의 속삭임", "기성 표지석"].forEach(n =>
      assert(S.npcs.some(x => x.name === n), "NPC " + n));
    assert(S.enemies.length >= 3, "숲에 몹 존재");
    assert(S.exits[0].label === "아스안 마을", "숲 남서 출구");
  });
  step("숲 → 마을 복귀 출구 + 탐험 기억 지속", () => {
    S.player.x = 2; S.player.y = 15;
    frames(40);
    assert(S.area === "town", "마을 복귀");
    assert(S.explored[18][17], "광장 탐험 기억 지속");
    assert(S.explored[8][40], "숲지기 자리 기억 지속");
    assert(!S.explored[2][46], "미탐험 지역은 그대로");
    S.player.x = 46; S.player.y = 2; frames(40); // 다시 숲으로
    assert(S.area === "forest", "재진입");
  });
  step("세 입구 중 하나 진입 → 던전 1층", () => {
    frames(15); // 진입 페이드 완전히 끝내기
    const g = S.npcs.find(n => n.name === "재의 왕좌");
    g.talk();
    frames(60);
    assert(S.area === "dungeon" && S.floor === 1, "던전 1층");
    assert(S.player.visited.has("haesung"), "기성 방문 기록(빠른 이동 해금)");
  });
  step("던전: 방 4개 + 십자 복도 구조", () => {
    const T = S.map.tiles;
    assert(T[8][8] === 0, "입구 (8,8) 복도");
    assert(T[4][5] === 0, "A방 바닥");
    assert(T[4][16] === 0, "B방 바닥");
    assert(T[12][5] === 0, "C방 바닥");
    assert(T[12][16] === 0, "D방 바닥");
    assert(T[8][15] === 0, "중앙 복도");
    assert(T[4][10] === 0, "세로 복도");
    assert(T[1][5] === 1, "방 밖은 벽");
    // 입구에서 계단/상자 전부 도달 가능
    const seen = new Set(["8,8"]);
    const q = [[8,8]];
    while (q.length) {
      const [x, y] = q.pop();
      [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx, dy]) => {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && ny >= 0 && nx < S.map.cols && ny < S.map.rows && T[ny][nx] !== 1 && !seen.has(nx + "," + ny)) {
          seen.add(nx + "," + ny); q.push([nx, ny]);
        }
      });
    }
    assert(seen.has(S.stairs.x + "," + S.stairs.y), "계단 도달 가능");
    S.chests.forEach(c => assert(seen.has(c.x + "," + c.y), "상자 도달 가능"));
    assert(S.stairs.x >= 12 && S.stairs.x <= 20 && S.stairs.y >= 10 && S.stairs.y <= 14, "계단은 D방");
    assert(!S.explored[2][16], "던전도 안개 적용(미탐험)");
    frames(30);
    assert(S.explored[8][8], "입구 주변 탐험됨");
  });
  step("던전 렌더/이동", () => { frames(60); key("a"); frames(50); key("a", false); });
  step("전투 시작", () => { const en = S.enemies.find(e => e.alive) || S.enemies[0]; D.startBattle(en); frames(30); });
  step("전투: 공격/스킬/적 턴", () => {
    D.battleAct("atk"); frames(40);
    S.player.mp = 99; D.battleAct("skill"); frames(40);
    frames(80);
  });
  step("전투 종료까지", () => {
    let guard = 0;
    while (S.screen === "battle" && guard++ < 200) {
      if (S.battle.turn === "player") { S.player.mp = 99; D.battleAct("skill"); }
      frames(90);
    }
    if (guard >= 200) throw new Error("전투 무한루프");
    frames(30);
  });
  step("3층: 지워진 해의 자리(모든 입구 공통)", () => {
    S.area = "dungeon"; S.floor = 3; S.player.dungeon = "ember"; D.spawnFloor();
    const n = S.npcs.find(x => x.name === "지워진 해의 자리");
    assert(n, "3층에 지워진 해의 자리 spawn (입구 무관)");
    S.player.x = n.x; S.player.y = n.y + 1; D.tryInteract(); frames(10);
    key(" "); frames(5); key(" "); frames(5);
  });
  step("3층 계단 → 숲 공터", () => {
    S.player.x = S.stairs.x; S.player.y = S.stairs.y + 1;
    D.tryInteract(); frames(60);
    assert(S.area === "forest", "숲 공터 복귀");
    assert(Math.round(S.player.x) === 13, "공터 도착 x=13");
  });
  step("개연의 제단(tide 2층)", () => {
    S.area = "dungeon"; S.floor = 2; S.player.dungeon = "tide"; D.spawnFloor();
    const n = S.npcs.find(x => x.name === "개연의 제단");
    if (n) { S.player.x = n.x; S.player.y = n.y + 1; D.tryInteract(); frames(10); key(" "); frames(5); }
    frames(30);
  });
  step("지역 이동: 숲 → 마을 (M 탭 경로)", () => {
    D.travel("asan"); frames(60);
    assert(S.area === "town", "마을 도착");
  });
  step("지역 이동: 기성 입구 앞 (방문 해금)", () => {
    D.travel("haesung"); frames(60);
    assert(S.area === "forest", "숲");
    assert(Math.round(S.player.x) === 13 && Math.round(S.player.y) === 5, "입구 앞 도착");
  });
  step("잠긴 지역 이동 불가", () => {
    D.travel("capital"); frames(20);
    assert(S.area === "forest", "왕도로 이동 안 됨");
  });
  step("불탄 마을 렌더", () => { S.player.burned = true; S.area = "town"; D.spawnFloor(); frames(60); });
  step("승리 화면", () => { S.player.codex.add("fold_dust"); S.player.relic = "relic_dream"; S.screen = "win"; frames(40); key("Enter"); frames(10); });
  step("재시작 + 긴 이동", () => {
    D.pickStory(0);
    assert(S.area === "town", "재시작 마을");
    key("d"); frames(120); key("d", false); key("s"); frames(80); key("s", false); frames(40);
  });

  console.log(failures.length ? `\n실패 ${failures.length}건: ${failures.join(", ")}` : "\n전체 통과");
  process.exit(failures.length ? 1 : 0);
})();
