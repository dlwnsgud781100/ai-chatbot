/* game.js + assets.js 런타임 스모크 테스트 (Node, DOM 스텁)
 * 흐름: 타이틀 → 마을 → 북동 출구 → 숲 → 세 입구 → 던전 → 전투 → 지역 이동
 */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

/* ---- 캔버스 2D 스텁 ---- */
function makeCtx() {
  const grad = { addColorStop() {} };
  return new Proxy({}, {
    get(t, k) {
      if (k === "measureText") return (s) => ({ width: String(s).length * 7 });
      if (k === "createLinearGradient" || k === "createRadialGradient" || k === "createPattern") return () => grad;
      if (k === "getImageData") return (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4).fill(255), width: w, height: h });
      if (k === "putImageData") return () => {};
      if (typeof k === "string" && !(k in t)) t[k] = () => undefined;
      return t[k];
    },
    set(t, k, v) { t[k] = v; return true; },
  });
}
function makeCanvas(id) {
  const el = makeEl(id);
  el.width = 1280; el.height = 720;
  el.getContext = () => makeCtx();
  el.getBoundingClientRect = () => ({ left: 0, top: 0, width: 1280, height: 720 });
  return el;
}
function makeEl(id) {
  const store = {};
  return {
    id, style: store, dataset: {},
    classList: { add() {}, remove() {}, contains: () => false, toggle() {} },
    innerHTML: "", textContent: "",
    addEventListener() {}, removeEventListener() {},
    querySelectorAll: () => [],
    setAttribute() {},
  };
}

const elements = {};
const ids = ["hud","hud-name","hud-lv","hp-fill","hp-text","mp-fill","mp-text","hud-gold",
  "hud-floor","hud-quest","hotbar","win-body","win-modal","win-title","win-close"];
ids.forEach(i => elements[i] = makeEl(i));
elements.minimap = makeCanvas("minimap");
elements.game = makeCanvas("game");

const winListeners = {};
const rafQueue = [];

const sandbox = {
  console,
  Math, Date, Uint8ClampedArray, Promise, Object, Array, JSON, Set, Map, parseInt, parseFloat, String, Number, Boolean, Error,
  performance: { now: () => Date.now() },
  requestAnimationFrame: (cb) => { rafQueue.push(cb); },
  setTimeout: (cb) => cb(),
  document: {
    getElementById: (id) => elements[id] || null,
    createElement: (tag) => makeCanvas(tag),
    querySelectorAll: () => [],
  },
  window: {},
  Image: class {
    constructor() { this._src = ""; }
    set src(v) {
      this._src = v;
      Promise.resolve().then(() => this.onload && this.onload());
    }
    get src() { return this._src; }
  },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
sandbox.window.addEventListener = (ev, cb) => { (winListeners[ev] = winListeners[ev] || []).push(cb); };

vm.createContext(sandbox);

function load(file) {
  const code = fs.readFileSync(path.join(__dirname, "..", "js", file), "utf8");
  vm.runInContext(code, sandbox, { filename: file });
}

process.on("unhandledRejection", (e) => { console.error("UNHANDLED", e); process.exit(1); });

let t = 0;
function frames(n) {
  for (let i = 0; i < n; i++) {
    t += 16.7;
    const q = rafQueue.splice(0);
    if (!q.length) break;
    q.forEach(cb => cb(t));
  }
}
function key(k, down = true) {
  (winListeners[down ? "keydown" : "keyup"] || []).forEach(cb => cb({ key: k, preventDefault() {} }));
}
function closeDialogs(S) { S.screen = "play"; S.dialog = null; }

const failures = [];
function step(name, fn) {
  try { fn(); console.log("✔", name); }
  catch (e) { failures.push(name); console.error("✘", name, "\n   ", e.stack.split("\n").slice(0, 4).join("\n    ")); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || "assertion failed"); }

(async () => {
  load("monsters.js");
  load("assets.js");
  load("game.js");
  const D = sandbox.window.__DBG;
  const S = D.state;

  step("타이틀 렌더 60프레임", () => frames(60));
  step("에셋 로드 대기", async () => { for (let i = 0; i < 50 && !D.GFX.on; i++) { await Promise.resolve(); frames(2); } if (!D.GFX.on) throw new Error("GFX 미활성"); });
  step("스토리 시작 → 아스안 마을", () => {
    D.pickStory(0);
    assert(S.area === "town", "시작 지역은 마을");
    assert(S.player.x === 7 && S.player.y === 12, "시작 위치 (7,12)");
  });
  step("마을: 포탈 NPC 제거 확인", () => {
    const gone = ["재의 왕좌", "이름 없는 해안", "뿌리의 속삭임"].every(n => !S.npcs.some(x => x.name === n));
    assert(gone, "마을에 던전 포탈이 없어야 함");
    assert(S.npcs.some(n => n.name === "북동 오솔길 표지"), "오솔길 표지 존재");
    assert(S.exits.length === 1 && S.exits[0].label === "북동 숲", "북동 출구 존재");
  });
  step("마을 렌더 + 이동(WASD)", () => { key("d"); frames(90); key("d", false); key("w"); frames(40); key("w", false); });
  step("NPC 대화(촌장)", () => { S.player.x = 5; S.player.y = 6; D.tryInteract(); frames(10); key(" "); frames(5); key(" "); frames(5); key(" "); frames(5); });
  step("우물 재앙 대화", () => { const w = S.npcs.find(n => n.name === "갈래 우물"); S.player.x = w.x; S.player.y = w.y + 1; D.tryInteract(); frames(5); key(" "); frames(30); });
  step("지역 패널 렌더", () => {
    D.travel("asan"); // 현재 지역 → 토스트만
    assert(D.panels.region.includes("아스안 마을"), "지역 패널에 마을");
    assert(D.panels.region.includes("왕도"), "잠긴 국가급 지역 표시");
    assert(D.panels.region.includes("길려진 해의 기성"), "기성 항목 존재");
  });
  step("북동 출구 → 숲 이동(페이드)", () => {
    closeDialogs(S);
    S.player.x = 26; S.player.y = 2;
    frames(2);
    assert(S.pendingTravel, "출구 밟으면 페이드 시작");
    frames(60);
    assert(S.area === "forest", "숲 도착");
    assert(S.player.visited.has("forest"), "숲 방문 기록");
  });
  step("숲: 세 입구 + 표지석 + 몹", () => {
    frames(60);
    ["재의 왕좌", "이름 없는 해안", "뿌리의 속삭임", "기성 표지석"].forEach(n =>
      assert(S.npcs.some(x => x.name === n), "NPC " + n));
    assert(S.enemies.length >= 3, "숲에 몹 존재");
    assert(S.exits[0].label === "아스안 마을", "숲 남서 출구");
  });
  step("숲 → 마을 복귀 출구", () => {
    S.player.x = 2; S.player.y = 15;
    frames(40);
    assert(S.area === "town", "마을 복귀");
    S.player.x = 26; S.player.y = 2; frames(40); // 다시 숲으로
    assert(S.area === "forest", "재진입");
  });
  step("세 입구 중 하나 진입 → 던전 1층", () => {
    frames(15); // 진입 페이드 완전히 끝내기
    const g = S.npcs.find(n => n.name === "재의 왕좌");
    g.talk();
    frames(60);
    assert(S.area === "dungeon" && S.floor === 1, "던전 1층");
    assert(S.player.visited.has("haesung"), "기성 방문 기록(빠른 이동 해금)");
  });
  step("던전 렌더/이동", () => { frames(60); key("a"); frames(50); key("a", false); });
  step("전투 시작", () => { const en = S.enemies.find(e => e.alive) || S.enemies[0]; D.startBattle(en); frames(30); });
  step("전투: 공격/스킬/적 턴", () => {
    D.battleAct("atk"); frames(40);
    S.player.mp = 99; D.battleAct("skill"); frames(40);
    frames(80);
  });
  step("전투 종료까지", () => {
    let guard = 0;
    while (S.screen === "battle" && guard++ < 200) {
      if (S.battle.turn === "player") { S.player.mp = 99; D.battleAct("skill"); }
      frames(90);
    }
    if (guard >= 200) throw new Error("전투 무한루프");
    frames(30);
  });
  step("3층: 지워진 해의 자리(모든 입구 공통)", () => {
    S.area = "dungeon"; S.floor = 3; S.player.dungeon = "ember"; D.spawnFloor();
    const n = S.npcs.find(x => x.name === "지워진 해의 자리");
    assert(n, "3층에 지워진 해의 자리 spawn (입구 무관)");
    S.player.x = n.x; S.player.y = n.y + 1; D.tryInteract(); frames(10);
    key(" "); frames(5); key(" "); frames(5);
  });
  step("3층 계단 → 숲 공터", () => {
    S.player.x = S.stairs.x; S.player.y = S.stairs.y + 1;
    D.tryInteract(); frames(60);
    assert(S.area === "forest", "숲 공터 복귀");
    assert(Math.round(S.player.x) === 13, "공터 도착 x=13");
  });
  step("개연의 제단(tide 2층)", () => {
    S.area = "dungeon"; S.floor = 2; S.player.dungeon = "tide"; D.spawnFloor();
    const n = S.npcs.find(x => x.name === "개연의 제단");
    if (n) { S.player.x = n.x; S.player.y = n.y + 1; D.tryInteract(); frames(10); key(" "); frames(5); }
    frames(30);
  });
  step("지역 이동: 숲 → 마을 (M 탭 경로)", () => {
    D.travel("asan"); frames(60);
    assert(S.area === "town", "마을 도착");
  });
  step("지역 이동: 기성 입구 앞 (방문 해금)", () => {
    D.travel("haesung"); frames(60);
    assert(S.area === "forest", "숲");
    assert(Math.round(S.player.x) === 13 && Math.round(S.player.y) === 5, "입구 앞 도착");
  });
  step("잠긴 지역 이동 불가", () => {
    D.travel("capital"); frames(20);
    assert(S.area === "forest", "왕도로 이동 안 됨");
  });
  step("불탄 마을 렌더", () => { S.player.burned = true; S.area = "town"; D.spawnFloor(); frames(60); });
  step("승리 화면", () => { S.player.codex.add("fold_dust"); S.player.relic = "relic_dream"; S.screen = "win"; frames(40); key("Enter"); frames(10); });
  step("재시작 + 긴 이동", () => {
    D.pickStory(0);
    assert(S.area === "town", "재시작 마을");
    key("d"); frames(120); key("d", false); key("s"); frames(80); key("s", false); frames(40);
  });

  console.log(failures.length ? `\n실패 ${failures.length}건: ${failures.join(", ")}` : "\n전체 통과");
  process.exit(failures.length ? 1 : 0);
})();
